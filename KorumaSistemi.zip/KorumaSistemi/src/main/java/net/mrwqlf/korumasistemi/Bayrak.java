package net.mrwqlf.korumasistemi;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;

/**
 * WorldGuard'daki "flag" karşılığı. Değer: 1 = izin/açık, 0 = yasak/kapalı.
 * Seçenekli (enum) bayraklarda değer, seçenek sırasıdır (0,1,2...).
 * Değer yoksa: bir üst katman / varsayılan geçerlidir.
 */
public enum Bayrak {
    // ---- Oyuncu eylemleri (claim'de güven yetkisine bağlı) ----
    BLOK_KIRMA("Blok Kırma", Material.IRON_PICKAXE, "Oyuncuların blok kırabilmesi.", TrustYetki.KIRMA, true, null, Kapsam.DB),
    BLOK_KOYMA("Blok Koyma", Material.GRASS_BLOCK, "Oyuncuların blok koyabilmesi ve ateş yakabilmesi.", TrustYetki.KOYMA, true, null, Kapsam.DB),
    KULLANIM("Kapı / Düğme / Kaldıraç", Material.OAK_DOOR, "Kapı, düğme, kaldıraç, basınç plakası gibi blokların kullanılması.", TrustYetki.KULLANIM, true, null, Kapsam.DB),
    SANDIK_ACMA("Sandık / Konteyner Açma", Material.CHEST, "Sandık, fırın, varil, huni gibi envanterli blokların açılması.", TrustYetki.SANDIK, true, null, Kapsam.DB),
    KOVA("Kova Kullanma", Material.BUCKET, "Su ve lav kovası ile sıvı koyma/alma.", TrustYetki.KOVA, true, null, Kapsam.DB),
    DEKOR("Çerçeve / Zırh Standı / Tablo", Material.ITEM_FRAME, "Eşya çerçevesi, tablo ve zırh standının değiştirilmesi/kırılması.", TrustYetki.DEKOR, true, null, Kapsam.DB),
    HAYVAN_ZARAR("Hayvan ve Köylülere Zarar", Material.BEEF, "Hayvanlara, köylülere ve pasif mobllara zarar verme / etkileşim.", TrustYetki.HAYVAN, true, null, Kapsam.DB),
    ESYA_ATMA("Eşya Atma", Material.DROPPER, "Oyuncuların yere eşya atabilmesi.", null, true, null, Kapsam.DB),
    ESYA_ALMA("Yerden Eşya Alma", Material.HOPPER, "Oyuncuların yerdeki eşyaları toplayabilmesi.", null, true, null, Kapsam.DB),
    ENDER_INCI("Ender İncisi / Chorus", Material.ENDER_PEARL, "Ender incisi ve chorus meyvesi ile ışınlanma.", null, true, null, Kapsam.DB),
    PVP("Oyuncu Savaşı (PvP)", Material.DIAMOND_SWORD, "Oyuncuların birbirine hasar verebilmesi.", null, true, null, Kapsam.HEPSI),

    // ---- Hasar / mob ----
    OYUNCU_HASAR("Oyuncu Hasar Alma", Material.TOTEM_OF_UNDYING, "Yasak olursa oyuncular hiçbir hasar almaz (ölümsüzlük).", null, true, null, Kapsam.DB),
    DUSME_HASARI("Düşme Hasarı", Material.FEATHER, "Yüksekten düşünce hasar alınması.", null, true, null, Kapsam.DB),
    ACLIK("Açlık Azalması", Material.COOKED_BEEF, "Yasak olursa oyuncuların açlığı azalmaz.", null, true, null, Kapsam.DB),
    DUSMAN_HASAR("Düşman Mob Hasarı", Material.ZOMBIE_HEAD, "Düşman moblerin oyunculara hasar verebilmesi.", null, true, null, Kapsam.DB),
    DUSMAN_MOB("Düşman Mob Doğması", Material.ROTTEN_FLESH, "Zombi, iskelet, creeper gibi düşman moblerin doğal doğması.", null, true, null, Kapsam.HEPSI),
    HAYVAN_DOGMA("Hayvan Doğması", Material.WHEAT, "İnek, koyun, domuz gibi hayvanların doğal doğması.", null, true, null, Kapsam.DB),

    // ---- Yıkım / doğa ----
    CREEPER_PATLAMA("Creeper Patlaması", Material.CREEPER_HEAD, "Creeper patlamalarının bloklara zarar vermesi.", null, true, Boolean.FALSE, Kapsam.HEPSI),
    TNT_PATLAMA("TNT ve Diğer Patlamalar", Material.TNT, "TNT, yatak, çapa, ender kristali gibi patlamaların bloklara zarar vermesi.", null, true, Boolean.FALSE, Kapsam.HEPSI),
    YANGIN_YAYILMA("Ateş Yayılması / Yanma", Material.FLINT_AND_STEEL, "Ateşin yayılması, blokların yanması, lav/yıldırım yangını.", null, true, Boolean.FALSE, Kapsam.HEPSI),
    MOB_BLOK_DEGISTIRME("Mob Blok Değiştirme", Material.ENDER_EYE, "Enderman, Wither, köylü gibi moblerin blok alması/değiştirmesi.", null, true, Boolean.FALSE, Kapsam.HEPSI),
    TARLA_EZME("Tarla Çiğneme", Material.FARMLAND, "Tarlaların üzerine basınca toprağa dönüşmesi.", null, true, Boolean.FALSE, Kapsam.HEPSI),
    SIVI_AKIS("Su / Lav Akışı", Material.WATER_BUCKET, "Su ve lavın akması (korumalı alanlara dışarıdan akış her zaman engellenir).", null, true, null, Kapsam.DB),
    YAPRAK_COKME("Yaprak Çürümesi", Material.OAK_LEAVES, "Ağaç yapraklarının kendiliğinden çürümesi.", null, true, null, Kapsam.DB),
    BUZ_ERIME("Buz ve Kar Erimesi", Material.ICE, "Buz ve karın erimesi.", null, true, null, Kapsam.DB),

    // ---- Hava / zaman / kar (WorldGuard'daki weather-lock, time-lock benzeri) ----
    HAVA("Hava Durumu Kilidi", Material.SUNFLOWER, "Havayı sabitler. Fırtına, dünya genelinde etkilidir; bölge/claim içinde yağmur olarak görünür.", Kapsam.HEPSI, "Güneşli", "Yağmur", "Fırtına"),
    ZAMAN("Zaman Kilidi", Material.CLOCK, "Saati sabitler.", Kapsam.HEPSI, "Gündüz", "Gün Batımı", "Gece"),
    KAR("Kar Yağışı", Material.SNOWBALL, "Her biyomda kar yağdırır (parçacık efekti).", Kapsam.HEPSI, "Hafif Kar", "Yoğun Kar"),
    KAR_BIRIKMESI("Kar Birikmesi", Material.SNOW_BLOCK, "Kar yağarken zemine kar tabakası birikir.", false, Kapsam.HEPSI, true);

    public final String ad;
    public final Material ikon;
    public final String aciklama;
    public final TrustYetki trust;
    public final boolean varsayilan;
    public final Boolean claimVarsayilan;
    public final int kapsam;
    public final String[] secenekler;
    public final boolean acikKapali;

    /** Evet/hayır bayrağı. */
    Bayrak(String ad, Material ikon, String aciklama, TrustYetki trust, boolean varsayilan, Boolean claimVarsayilan, int kapsam) {
        this.ad = ad;
        this.ikon = ikon;
        this.aciklama = aciklama;
        this.trust = trust;
        this.varsayilan = varsayilan;
        this.claimVarsayilan = claimVarsayilan;
        this.kapsam = kapsam;
        this.secenekler = null;
        this.acikKapali = false;
    }

    /** Seçenekli ayar (hava, zaman, kar). */
    Bayrak(String ad, Material ikon, String aciklama, int kapsam, String... secenekler) {
        this.ad = ad;
        this.ikon = ikon;
        this.aciklama = aciklama;
        this.trust = null;
        this.varsayilan = false;
        this.claimVarsayilan = null;
        this.kapsam = kapsam;
        this.secenekler = secenekler;
        this.acikKapali = true;
    }

    /** Açık/Kapalı etiketli evet-hayır ayarı. */
    Bayrak(String ad, Material ikon, String aciklama, boolean varsayilan, int kapsam, boolean acikKapali) {
        this.ad = ad;
        this.ikon = ikon;
        this.aciklama = aciklama;
        this.trust = null;
        this.varsayilan = varsayilan;
        this.claimVarsayilan = null;
        this.kapsam = kapsam;
        this.secenekler = null;
        this.acikKapali = acikKapali;
    }

    public boolean enumMi() {
        return secenekler != null;
    }

    public boolean kapsamda(int k) {
        return (kapsam & k) != 0;
    }

    public boolean claimDestek() {
        return kapsamda(Kapsam.C);
    }

    public String izinEtiketi() {
        return acikKapali ? "AÇIK" : "İZİN VERİLİR";
    }

    public String yasakEtiketi() {
        return acikKapali ? "KAPALI" : "YASAK";
    }

    public String yokEtiketi() {
        return this == KAR ? "Kapalı" : "Kilitsiz (doğal)";
    }

    public static List<Bayrak> kapsamdakiler(int k) {
        List<Bayrak> l = new ArrayList<>();
        for (Bayrak b : values()) {
            if (b.kapsamda(k)) l.add(b);
        }
        return l;
    }
}
