package net.mrwqlf.korumasistemi;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

/** Tüm koruma verisi ve karar mantığı burada. */
public final class KorumaYoneticisi {
    public record Karar(boolean izin, String mesaj) {
        public static final Karar TAMAM = new Karar(true, null);
    }

    public record EnumSonuc(int deger, Katman katman) {
        public boolean var() {
            return deger >= 0;
        }
    }

    public record AlanBilgi(String anahtar, String ad, boolean claim, UUID sahip) {}

    private final KorumaSistemi eklenti;
    private final Map<String, DunyaAyari> dunyalar = new HashMap<>();
    private final Map<UUID, List<Bolge>> bolgeler = new HashMap<>();
    private final Map<UUID, Claim> claimler = new LinkedHashMap<>();
    private final Map<UUID, Map<Long, List<Claim>>> indeks = new HashMap<>();
    private final Set<UUID> bypassKapali = new HashSet<>();
    private BukkitTask planli;

    public KorumaYoneticisi(KorumaSistemi eklenti) {
        this.eklenti = eklenti;
    }

    // ------------------------------------------------------------------ dünya

    public DunyaAyari dunya(World w) {
        return dunya(w.getName());
    }

    public DunyaAyari dunya(String ad) {
        return dunyalar.computeIfAbsent(ad, DunyaAyari::new);
    }

    /** Dünya koruması aktifse dünya bayrağının değeri, aksi halde -1. */
    public int dunyaDeger(World w, Bayrak b) {
        DunyaAyari d = dunya(w);
        if (!d.aktif) return -1;
        Integer v = d.al(b);
        return v == null ? -1 : v;
    }

    // ------------------------------------------------------------------ bölge

    public List<Bolge> bolgeListesi(UUID dunya) {
        return bolgeler.getOrDefault(dunya, List.of());
    }

    public Collection<List<Bolge>> tumBolgeler() {
        return bolgeler.values();
    }

    public Bolge bolgeAdla(UUID dunya, String ad) {
        for (Bolge b : bolgeListesi(dunya)) {
            if (b.ad.equalsIgnoreCase(ad)) return b;
        }
        return null;
    }

    public void bolgeEkle(Bolge b) {
        bolgeler.computeIfAbsent(b.dunya, k -> new ArrayList<>()).add(b);
        bolgeSirala(b.dunya);
        kaydetPlanla();
    }

    public void bolgeSil(Bolge b) {
        List<Bolge> l = bolgeler.get(b.dunya);
        if (l != null) l.remove(b);
        kaydetPlanla();
    }

    public void bolgeSirala(UUID dunya) {
        List<Bolge> l = bolgeler.get(dunya);
        if (l != null) l.sort(Comparator.comparingInt((Bolge x) -> -x.oncelik).thenComparingLong(Bolge::hacim));
    }

    // ------------------------------------------------------------------ claim

    private static long anahtar(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xffffffffL);
    }

    public Collection<Claim> claimler() {
        return claimler.values();
    }

    public List<Claim> oyuncuClaimleri(UUID oyuncu) {
        List<Claim> l = new ArrayList<>();
        for (Claim c : claimler.values()) {
            if (c.sahip.equals(oyuncu)) l.add(c);
        }
        return l;
    }

    public void claimEkle(Claim c) {
        claimler.put(c.id, c);
        indeksle(c);
        kaydetPlanla();
    }

    private void indeksle(Claim c) {
        Map<Long, List<Claim>> m = indeks.computeIfAbsent(c.dunya, k -> new HashMap<>());
        for (int cx = c.minX >> 4; cx <= c.maxX >> 4; cx++) {
            for (int cz = c.minZ >> 4; cz <= c.maxZ >> 4; cz++) {
                m.computeIfAbsent(anahtar(cx, cz), k -> new ArrayList<>(2)).add(c);
            }
        }
    }

    public void claimSil(Claim c) {
        claimler.remove(c.id);
        Map<Long, List<Claim>> m = indeks.get(c.dunya);
        if (m != null) {
            for (int cx = c.minX >> 4; cx <= c.maxX >> 4; cx++) {
                for (int cz = c.minZ >> 4; cz <= c.maxZ >> 4; cz++) {
                    long key = anahtar(cx, cz);
                    List<Claim> l = m.get(key);
                    if (l != null) {
                        l.remove(c);
                        if (l.isEmpty()) m.remove(key);
                    }
                }
            }
        }
        kaydetPlanla();
    }

    public Claim claimBul(UUID dunya, int x, int z) {
        Map<Long, List<Claim>> m = indeks.get(dunya);
        if (m == null) return null;
        List<Claim> l = m.get(anahtar(x >> 4, z >> 4));
        if (l == null) return null;
        for (Claim c : l) {
            if (c.icinde(x, z)) return c;
        }
        return null;
    }

    // ------------------------------------------------------------------ bypass

    public boolean bypass(Player p) {
        return p.hasPermission("korumasistemi.admin") && !bypassKapali.contains(p.getUniqueId());
    }

    /** @return bypass'ın yeni durumu (true = açık) */
    public boolean bypassDegistir(Player p) {
        if (bypassKapali.remove(p.getUniqueId())) return true;
        bypassKapali.add(p.getUniqueId());
        return false;
    }

    // ------------------------------------------------------------------ karar mantığı

    /** Oyuncuya bağlı olmayan (doğa/mob) bayraklar ve genel bayraklar için: bölge > claim > dünya. */
    public boolean izinli(Bayrak b, Location l) {
        World w = l.getWorld();
        if (w == null) return true;
        int x = l.getBlockX(), y = l.getBlockY(), z = l.getBlockZ();
        UUID wid = w.getUID();
        for (Bolge bo : bolgeListesi(wid)) {
            if (bo.icinde(x, y, z)) {
                Integer v = bo.al(b);
                if (v != null) return v == 1;
            }
        }
        if (b.claimDestek()) {
            Claim c = claimBul(wid, x, z);
            if (c != null) {
                Integer v = c.al(b);
                if (v != null) return v == 1;
                if (b.claimVarsayilan != null) return b.claimVarsayilan;
            }
        }
        DunyaAyari d = dunya(w);
        if (!d.aktif) return b.varsayilan;
        Integer v = d.al(b);
        return v == null ? b.varsayilan : v == 1;
    }

    /** Güven yetkisine bağlı oyuncu eylemleri (kırma, koyma, kullanma...). */
    public Karar karar(Player p, Bayrak b, Location l) {
        if (bypass(p)) return Karar.TAMAM;
        World w = l.getWorld();
        if (w == null) return Karar.TAMAM;
        int x = l.getBlockX(), y = l.getBlockY(), z = l.getBlockZ();
        UUID wid = w.getUID();

        for (Bolge bo : bolgeListesi(wid)) {
            if (bo.icinde(x, y, z)) {
                if (bo.uye(p.getUniqueId())) return Karar.TAMAM;
                Integer v = bo.al(b);
                if (v != null && v == 1) return Karar.TAMAM;
                return new Karar(false, "&cBu bölge korumalı: &f" + bo.ad + " &7(" + b.ad + " yasak)");
            }
        }

        Claim c = claimBul(wid, x, z);
        if (c != null && b.trust != null) {
            if (c.yetkili(p.getUniqueId(), b.trust)) return Karar.TAMAM;
            return new Karar(false, "&cBu alan &f" + c.sahipAdi + " &coyuncusunun claim'i! &7Gereken yetki: &f" + b.trust.ad);
        }

        DunyaAyari d = dunya(w);
        if (!d.aktif) return Karar.TAMAM;
        Integer v = d.al(b);
        boolean izin = v == null ? b.varsayilan : v == 1;
        return izin ? Karar.TAMAM : new Karar(false, "&cBu dünyada bu eylem yasak: &f" + b.ad);
    }

    /** Seçenekli ayarlar (hava, zaman, kar) için en üst katmandaki değeri bulur. */
    public EnumSonuc enumCoz(Bayrak b, Location l) {
        World w = l.getWorld();
        if (w == null) return new EnumSonuc(-1, Katman.DUNYA);
        int x = l.getBlockX(), y = l.getBlockY(), z = l.getBlockZ();
        UUID wid = w.getUID();
        for (Bolge bo : bolgeListesi(wid)) {
            if (bo.icinde(x, y, z)) {
                Integer v = bo.al(b);
                if (v != null) return new EnumSonuc(v, Katman.BOLGE);
            }
        }
        Claim c = claimBul(wid, x, z);
        if (c != null) {
            Integer v = c.al(b);
            if (v != null) return new EnumSonuc(v, Katman.CLAIM);
        }
        int dv = dunyaDeger(w, b);
        return new EnumSonuc(dv, Katman.DUNYA);
    }

    /** Konumdaki koruma alanı (bölge veya claim) nesnesi; yoksa null. Karşılaştırma için kullanılır. */
    public Object alanNesnesi(World w, int x, int y, int z) {
        UUID wid = w.getUID();
        for (Bolge bo : bolgeListesi(wid)) {
            if (bo.icinde(x, y, z)) return bo;
        }
        return claimBul(wid, x, z);
    }

    /** İki alan aynı nesne veya aynı sahibin iki claim'i ise true (huni, piston, sıvı geçişleri için). */
    public boolean ayniSahip(Object a, Object b) {
        if (a == b) return true;
        return a instanceof Claim x && b instanceof Claim y && x.sahip.equals(y.sahip);
    }

    public Object alanNesnesi(Block b) {
        return alanNesnesi(b.getWorld(), b.getX(), b.getY(), b.getZ());
    }

    public AlanBilgi alanBilgi(Location l) {
        World w = l.getWorld();
        if (w == null) return null;
        Object o = alanNesnesi(w, l.getBlockX(), l.getBlockY(), l.getBlockZ());
        if (o instanceof Bolge b) return new AlanBilgi("B:" + b.uid, b.ad, false, null);
        if (o instanceof Claim c) return new AlanBilgi("C:" + c.id, c.sahipAdi, true, c.sahip);
        return null;
    }

    // ------------------------------------------------------------------ kayıt

    public void kaydetPlanla() {
        if (planli != null) return;
        planli = Bukkit.getScheduler().runTaskLater(eklenti, () -> {
            planli = null;
            kaydet();
        }, 100L);
    }

    private YamlConfiguration yeniYaml() {
        YamlConfiguration y = new YamlConfiguration();
        y.options().pathSeparator('/');
        return y;
    }

    private YamlConfiguration yukleYaml(File f) {
        YamlConfiguration y = yeniYaml();
        try {
            y.load(f);
        } catch (Exception ex) {
            eklenti.getLogger().log(Level.SEVERE, f.getName() + " okunamadı!", ex);
        }
        return y;
    }

    private void bayrakYaz(ConfigurationSection s, BayrakSahibi h) {
        ConfigurationSection bs = s.createSection("bayraklar");
        for (Map.Entry<Bayrak, Integer> e : h.tumu().entrySet()) {
            bs.set(e.getKey().name(), e.getValue());
        }
    }

    private void bayrakOku(ConfigurationSection s, BayrakSahibi h) {
        ConfigurationSection bs = s.getConfigurationSection("bayraklar");
        if (bs == null) return;
        for (String k : bs.getKeys(false)) {
            try {
                h.koy(Bayrak.valueOf(k), bs.getInt(k));
            } catch (IllegalArgumentException ignored) {
                // eski/bilinmeyen bayrak
            }
        }
    }

    public void kaydet() {
        if (planli != null) {
            planli.cancel();
            planli = null;
        }
        File klasor = eklenti.getDataFolder();
        if (!klasor.exists() && !klasor.mkdirs()) {
            eklenti.getLogger().severe("Veri klasörü oluşturulamadı!");
            return;
        }

        YamlConfiguration yd = yeniYaml();
        for (DunyaAyari d : dunyalar.values()) {
            ConfigurationSection s = yd.createSection("dunyalar/" + d.dunyaAdi);
            s.set("aktif", d.aktif);
            s.set("claim-acik", d.claimAcik);
            bayrakYaz(s, d);
        }
        yazDosya(yd, new File(klasor, "dunyalar.yml"));

        YamlConfiguration yb = yeniYaml();
        for (List<Bolge> l : bolgeler.values()) {
            for (Bolge b : l) {
                ConfigurationSection s = yb.createSection("bolgeler/" + b.uid);
                s.set("ad", b.ad);
                s.set("dunya", b.dunya.toString());
                s.set("dunya-ad", b.dunyaAdi);
                s.set("min-x", b.minX);
                s.set("min-y", b.minY);
                s.set("min-z", b.minZ);
                s.set("max-x", b.maxX);
                s.set("max-y", b.maxY);
                s.set("max-z", b.maxZ);
                s.set("oncelik", b.oncelik);
                List<String> uyeler = new ArrayList<>();
                for (UUID u : b.uyeler) uyeler.add(u.toString());
                s.set("uyeler", uyeler);
                bayrakYaz(s, b);
            }
        }
        yazDosya(yb, new File(klasor, "bolgeler.yml"));

        YamlConfiguration yc = yeniYaml();
        for (Claim c : claimler.values()) {
            ConfigurationSection s = yc.createSection("claimler/" + c.id);
            s.set("sahip", c.sahip.toString());
            s.set("sahip-ad", c.sahipAdi);
            s.set("dunya", c.dunya.toString());
            s.set("dunya-ad", c.dunyaAdi);
            s.set("min-x", c.minX);
            s.set("min-z", c.minZ);
            s.set("max-x", c.maxX);
            s.set("max-z", c.maxZ);
            s.set("olusturma", c.olusturma);
            ConfigurationSection g = s.createSection("guven");
            for (Map.Entry<UUID, EnumSet<TrustYetki>> e : c.guven.entrySet()) {
                List<String> yetkiler = new ArrayList<>();
                for (TrustYetki t : e.getValue()) yetkiler.add(t.name());
                g.set(e.getKey().toString(), yetkiler);
            }
            bayrakYaz(s, c);
        }
        yazDosya(yc, new File(klasor, "claimler.yml"));
    }

    private void yazDosya(YamlConfiguration y, File f) {
        try {
            y.save(f);
        } catch (IOException ex) {
            eklenti.getLogger().log(Level.SEVERE, f.getName() + " kaydedilemedi!", ex);
        }
    }

    public void yukle() {
        dunyalar.clear();
        bolgeler.clear();
        claimler.clear();
        indeks.clear();
        File klasor = eklenti.getDataFolder();

        File fd = new File(klasor, "dunyalar.yml");
        if (fd.exists()) {
            ConfigurationSection kok = yukleYaml(fd).getConfigurationSection("dunyalar");
            if (kok != null) {
                for (String ad : kok.getKeys(false)) {
                    ConfigurationSection s = kok.getConfigurationSection(ad);
                    if (s == null) continue;
                    DunyaAyari d = new DunyaAyari(ad);
                    d.aktif = s.getBoolean("aktif", true);
                    d.claimAcik = s.getBoolean("claim-acik", true);
                    bayrakOku(s, d);
                    dunyalar.put(ad, d);
                }
            }
        }

        File fb = new File(klasor, "bolgeler.yml");
        if (fb.exists()) {
            ConfigurationSection kok = yukleYaml(fb).getConfigurationSection("bolgeler");
            if (kok != null) {
                for (String id : kok.getKeys(false)) {
                    ConfigurationSection s = kok.getConfigurationSection(id);
                    if (s == null) continue;
                    try {
                        Bolge b = new Bolge(UUID.fromString(id), s.getString("ad", id),
                                UUID.fromString(s.getString("dunya", "")), s.getString("dunya-ad", "?"),
                                s.getInt("min-x"), s.getInt("min-y"), s.getInt("min-z"),
                                s.getInt("max-x"), s.getInt("max-y"), s.getInt("max-z"));
                        b.oncelik = s.getInt("oncelik", 0);
                        for (String u : s.getStringList("uyeler")) b.uyeler.add(UUID.fromString(u));
                        bayrakOku(s, b);
                        bolgeler.computeIfAbsent(b.dunya, k -> new ArrayList<>()).add(b);
                    } catch (IllegalArgumentException ex) {
                        eklenti.getLogger().warning("Bozuk bölge kaydı atlandı: " + id);
                    }
                }
                for (UUID w : new ArrayList<>(bolgeler.keySet())) bolgeSirala(w);
            }
        }

        File fc = new File(klasor, "claimler.yml");
        if (fc.exists()) {
            ConfigurationSection kok = yukleYaml(fc).getConfigurationSection("claimler");
            if (kok != null) {
                for (String id : kok.getKeys(false)) {
                    ConfigurationSection s = kok.getConfigurationSection(id);
                    if (s == null) continue;
                    try {
                        Claim c = new Claim(UUID.fromString(id), UUID.fromString(s.getString("sahip", "")),
                                s.getString("sahip-ad", "?"), UUID.fromString(s.getString("dunya", "")),
                                s.getString("dunya-ad", "?"), s.getInt("min-x"), s.getInt("min-z"),
                                s.getInt("max-x"), s.getInt("max-z"), s.getLong("olusturma"));
                        ConfigurationSection g = s.getConfigurationSection("guven");
                        if (g != null) {
                            for (String u : g.getKeys(false)) {
                                EnumSet<TrustYetki> set = EnumSet.noneOf(TrustYetki.class);
                                for (String t : g.getStringList(u)) {
                                    try {
                                        set.add(TrustYetki.valueOf(t));
                                    } catch (IllegalArgumentException ignored) {
                                        // bilinmeyen yetki
                                    }
                                }
                                if (!set.isEmpty()) c.guven.put(UUID.fromString(u), set);
                            }
                        }
                        bayrakOku(s, c);
                        claimler.put(c.id, c);
                        indeksle(c);
                    } catch (IllegalArgumentException ex) {
                        eklenti.getLogger().warning("Bozuk claim kaydı atlandı: " + id);
                    }
                }
            }
        }
    }
}
