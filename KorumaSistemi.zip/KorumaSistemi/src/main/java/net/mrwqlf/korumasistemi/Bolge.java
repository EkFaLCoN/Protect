package net.mrwqlf.korumasistemi;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class Bolge extends BayrakSahibi {
    public final UUID uid;
    public final String ad;
    public final UUID dunya;
    public final String dunyaAdi;
    public final int minX, minY, minZ, maxX, maxY, maxZ;
    public int oncelik = 0;
    public final Set<UUID> uyeler = new HashSet<>();

    public Bolge(UUID uid, String ad, UUID dunya, String dunyaAdi,
                 int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        this.uid = uid;
        this.ad = ad;
        this.dunya = dunya;
        this.dunyaAdi = dunyaAdi;
        this.minX = minX;
        this.minY = minY;
        this.minZ = minZ;
        this.maxX = maxX;
        this.maxY = maxY;
        this.maxZ = maxZ;
    }

    public boolean icinde(int x, int y, int z) {
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    public boolean kesisirXZ(int aMinX, int aMinZ, int aMaxX, int aMaxZ) {
        return !(aMaxX < minX || aMinX > maxX || aMaxZ < minZ || aMinZ > maxZ);
    }

    public boolean uye(UUID u) {
        return uyeler.contains(u);
    }

    public long hacim() {
        return (long) (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
    }

    @Override
    public Katman katman() {
        return Katman.BOLGE;
    }

    @Override
    public String baslik() {
        return "Bölge: " + ad;
    }
}
