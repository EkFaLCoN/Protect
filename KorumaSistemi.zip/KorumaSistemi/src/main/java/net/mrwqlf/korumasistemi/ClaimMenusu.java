package net.mrwqlf.korumasistemi;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.text.SimpleDateFormat;
import java.util.Date;

/** /claim ile açılan ana claim menüsü. */
public final class ClaimMenusu extends Menu {
    private final KorumaSistemi pl;
    private final Claim claim;
    private boolean silOnay = false;

    private ClaimMenusu(KorumaSistemi pl, Claim claim) {
        this.pl = pl;
        this.claim = claim;
        this.env = Bukkit.createInventory(this, 27, Yazi.k("&8Claim » " + claim.sahipAdi));
    }

    public static void ac(KorumaSistemi pl, Player p, Claim claim) {
        ClaimMenusu m = new ClaimMenusu(pl, claim);
        m.yenile();
        p.openInventory(m.env);
    }

    private void yenile() {
        env.clear();
        String tarih = new SimpleDateFormat("dd.MM.yyyy HH:mm").format(new Date(claim.olusturma));
        env.setItem(10, esya(Material.PAPER, "&e&lClaim Bilgisi",
                "&7Sahip: &f" + claim.sahipAdi,
                "&7Boyut: &f" + claim.genislik() + " x " + claim.uzunluk() + " &7(" + claim.alan() + " blok)",
                "&7X: &f" + claim.minX + " &7→ &f" + claim.maxX,
                "&7Z: &f" + claim.minZ + " &7→ &f" + claim.maxZ,
                "&7Dünya: &f" + claim.dunyaAdi,
                "&7Güvenilen: &f" + claim.guven.size() + " &7kişi/grup",
                "&7Oluşturma: &f" + tarih));
        env.setItem(12, esya(Material.COMPARATOR, "&b&lBayraklar",
                "&7PvP, patlama, yangın, mob, tarla,", "&7hava, zaman ve kar ayarları.", "", "&8▸ &7Tıkla: &fdüzenle"));
        env.setItem(14, esya(Material.PLAYER_HEAD, "&a&lGüvenilen Oyuncular",
                "&7Yetki verdiklerini gör ve düzenle.", "&7Yeni yetki: &f/trust <oyuncu>", "", "&8▸ &7Tıkla: &fliste"));
        env.setItem(16, esya(Material.END_ROD, "&d&lSınırları Göster", "&7Claim sınırlarını parçacıkla göster."));
        if (silOnay) {
            env.setItem(22, esya(Material.TNT, "&4&lEMİN MİSİN?", "&cClaim kalıcı olarak silinecek!", "", "&8▸ &7Onaylamak için tekrar tıkla"));
        } else {
            env.setItem(22, esya(Material.LAVA_BUCKET, "&c&lClaim'i Sil", "&7Bu claim'i tamamen kaldırır.", "", "&8▸ &7Tıkla: &fsil"));
        }
        env.setItem(26, esya(Material.BARRIER, "&cKapat"));
    }

    @Override
    public void tikla(InventoryClickEvent e) {
        Player p = (Player) e.getWhoClicked();
        boolean yetkili = claim.sahip.equals(p.getUniqueId()) || p.hasPermission("korumasistemi.admin");
        if (!yetkili) {
            p.closeInventory();
            return;
        }
        switch (e.getSlot()) {
            case 12 -> BayrakMenusu.ac(pl, p, claim, () -> ClaimMenusu.ac(pl, p, claim));
            case 14 -> GuvenListesiMenusu.ac(pl, p, claim);
            case 16 -> {
                p.closeInventory();
                Sinir.goster(pl, p, claim);
            }
            case 22 -> {
                if (!silOnay) {
                    silOnay = true;
                    yenile();
                } else {
                    pl.yonetici().claimSil(claim);
                    p.closeInventory();
                    Yazi.mesaj(p, "&cClaim silindi.");
                }
            }
            case 26 -> p.closeInventory();
            default -> { }
        }
    }
}
