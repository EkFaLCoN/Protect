package net.mrwqlf.korumasistemi;

public final class DunyaAyari extends BayrakSahibi {
    public final String dunyaAdi;
    /** Dünya korumasının ana şalteri. Kapalıysa dünya bayrakları yok sayılır. */
    public boolean aktif = true;
    /** Bu dünyada claim atılabilir mi? */
    public boolean claimAcik = true;

    public DunyaAyari(String dunyaAdi) {
        this.dunyaAdi = dunyaAdi;
    }

    @Override
    public Katman katman() {
        return Katman.DUNYA;
    }

    @Override
    public String baslik() {
        return "Dünya: " + dunyaAdi;
    }
}
