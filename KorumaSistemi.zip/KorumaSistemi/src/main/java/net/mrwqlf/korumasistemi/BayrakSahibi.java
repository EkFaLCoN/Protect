package net.mrwqlf.korumasistemi;

import java.util.EnumMap;
import java.util.Map;

/** Bayrak tutan her şeyin (dünya, bölge, claim) ortak tabanı. */
public abstract class BayrakSahibi {
    protected final EnumMap<Bayrak, Integer> bayraklar = new EnumMap<>(Bayrak.class);

    public Integer al(Bayrak b) {
        return bayraklar.get(b);
    }

    public void koy(Bayrak b, int deger) {
        bayraklar.put(b, deger);
    }

    public void sil(Bayrak b) {
        bayraklar.remove(b);
    }

    public Map<Bayrak, Integer> tumu() {
        return bayraklar;
    }

    public abstract Katman katman();

    public abstract String baslik();
}
