package net.mrwqlf.korumasistemi;

import org.bukkit.Bukkit;
import org.bukkit.World;

/** Dünya genelindeki hava ve zaman kilitlerini uygular. */
public final class DunyaGorevi implements Runnable {
    private static final long[] ZAMANLAR = {6000L, 12500L, 18000L};
    private final KorumaYoneticisi km;

    public DunyaGorevi(KorumaSistemi pl) {
        this.km = pl.yonetici();
    }

    @Override
    public void run() {
        for (World w : Bukkit.getWorlds()) {
            int hava = km.dunyaDeger(w, Bayrak.HAVA);
            switch (hava) {
                case 0 -> {
                    if (w.hasStorm()) w.setStorm(false);
                    if (w.isThundering()) w.setThundering(false);
                }
                case 1 -> {
                    if (!w.hasStorm()) {
                        w.setStorm(true);
                        w.setWeatherDuration(12000);
                    }
                    if (w.isThundering()) w.setThundering(false);
                }
                case 2 -> {
                    if (!w.hasStorm()) {
                        w.setStorm(true);
                        w.setWeatherDuration(12000);
                    }
                    if (!w.isThundering()) {
                        w.setThundering(true);
                        w.setThunderDuration(12000);
                    }
                }
                default -> { }
            }
            int zaman = km.dunyaDeger(w, Bayrak.ZAMAN);
            if (zaman >= 0 && zaman < ZAMANLAR.length) w.setTime(ZAMANLAR[zaman]);
        }
    }
}
