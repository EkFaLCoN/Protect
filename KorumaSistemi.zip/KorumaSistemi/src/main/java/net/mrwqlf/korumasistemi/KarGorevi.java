package net.mrwqlf.korumasistemi;

import net.mrwqlf.korumasistemi.KorumaYoneticisi.EnumSonuc;
import org.bukkit.Bukkit;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Snow;
import org.bukkit.entity.Player;

import java.util.concurrent.ThreadLocalRandom;

/** Kar parçacıklarını gösterir ve (açıksa) zemine kar tabakası biriktirir. */
public final class KarGorevi implements Runnable {
    private final KorumaSistemi pl;
    private final KorumaYoneticisi km;
    private int tik = 0;

    public KarGorevi(KorumaSistemi pl) {
        this.pl = pl;
        this.km = pl.yonetici();
    }

    @Override
    public void run() {
        tik++;
        for (Player p : Bukkit.getOnlinePlayers()) {
            int[] k = pl.alanGorevi().karDurumu(p.getUniqueId());
            if (k == null || k[0] < 0) continue;
            World w = p.getWorld();
            if (w.getEnvironment() != World.Environment.NORMAL) continue;
            Location l = p.getLocation();
            if (l.getBlock().getLightFromSky() < 12) continue; // kapalı alanda kar yağmasın

            int adet = k[0] == 0 ? pl.getConfig().getInt("kar.parcacik-hafif", 12)
                    : pl.getConfig().getInt("kar.parcacik-yogun", 36);
            ThreadLocalRandom r = ThreadLocalRandom.current();
            for (int i = 0; i < adet; i++) {
                double aci = r.nextDouble() * Math.PI * 2;
                double uzak = Math.sqrt(r.nextDouble()) * 12;
                double x = l.getX() + Math.cos(aci) * uzak;
                double z = l.getZ() + Math.sin(aci) * uzak;
                double y = l.getY() + 2 + r.nextDouble() * 7;
                p.spawnParticle(Particle.SNOWFLAKE, x, y, z, 0, (r.nextDouble() - 0.5) * 0.3, -1.0, (r.nextDouble() - 0.5) * 0.3, 0.07);
            }

            if (k[1] == 1 && tik % 10 == 0) birikme(p, k[0]);
        }
    }

    private void birikme(Player p, int seviye) {
        World w = p.getWorld();
        int deneme = seviye == 0 ? 3 : 8;
        int yaricap = Math.max(4, pl.getConfig().getInt("kar.yaricap", 14));
        int maks = Math.max(1, Math.min(8, pl.getConfig().getInt("kar.en-fazla-katman", 3)));
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Location pl0 = p.getLocation();
        BlockData tabaka = Material.SNOW.createBlockData();

        for (int i = 0; i < deneme; i++) {
            int x = pl0.getBlockX() + r.nextInt(-yaricap, yaricap + 1);
            int z = pl0.getBlockZ() + r.nextInt(-yaricap, yaricap + 1);
            if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
            Block ust = w.getHighestBlockAt(x, z, HeightMap.MOTION_BLOCKING);
            Location ul = ust.getLocation();

            EnumSonuc ks = km.enumCoz(Bayrak.KAR, ul);
            if (!ks.var()) continue;
            if (km.enumCoz(Bayrak.KAR_BIRIKMESI, ul).deger() != 1) continue;

            if (ust.getType() == Material.SNOW) {
                if (ust.getBlockData() instanceof Snow s && s.getLayers() < Math.min(maks, s.getMaximumLayers())) {
                    s.setLayers(s.getLayers() + 1);
                    ust.setBlockData(s, false);
                }
                continue;
            }
            if (ust.isLiquid()) continue;
            Block ustu = ust.getRelative(BlockFace.UP);
            Material m = ustu.getType();
            boolean bos = ustu.isEmpty() || m == Material.SHORT_GRASS || m == Material.FERN;
            if (!bos || !ustu.canPlace(tabaka)) continue;
            ustu.setType(Material.SNOW, false);
        }
    }
}
