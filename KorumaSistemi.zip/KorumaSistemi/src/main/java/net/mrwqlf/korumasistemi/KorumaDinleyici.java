package net.mrwqlf.korumasistemi;

import net.mrwqlf.korumasistemi.KorumaYoneticisi.Karar;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.Animals;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Hanging;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Villager;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketEntityEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.world.PortalCreateEvent;
import org.bukkit.event.world.StructureGrowEvent;
import org.bukkit.event.weather.ThunderChangeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Tüm koruma olaylarını dinler. */
public final class KorumaDinleyici implements Listener {
    private static final Set<String> DUSMAN_SEBEPLER = Set.of("NATURAL", "CHUNK_GEN", "REINFORCEMENTS",
            "VILLAGE_INVASION", "PATROL", "RAID", "TRAP", "JOCKEY", "LIGHTNING", "NETHER_PORTAL", "MOUNT");
    private static final Set<String> HAYVAN_SEBEPLER = Set.of("NATURAL", "CHUNK_GEN");

    private final KorumaSistemi pl;
    private final KorumaYoneticisi km;
    private final Map<UUID, Long> sonMesaj = new HashMap<>();
    private record Olum(Location yer, long zaman) {}
    private final Map<UUID, Olum> olumler = new HashMap<>();

    public KorumaDinleyici(KorumaSistemi pl) {
        this.pl = pl;
        this.km = pl.yonetici();
    }

    // ------------------------------------------------------------ yardımcılar

    private void uyar(Player p, String msg) {
        long simdi = System.currentTimeMillis();
        Long son = sonMesaj.get(p.getUniqueId());
        if (son != null && simdi - son < 1200) return;
        sonMesaj.put(p.getUniqueId(), simdi);
        Yazi.aksiyon(p, msg);
    }

    /** @return true = izinli */
    private boolean kontrol(Player p, Bayrak b, Location l) {
        Karar k = km.karar(p, b, l);
        if (k.izin()) return true;
        uyar(p, k.mesaj());
        return false;
    }

    /** Güven yetkisi gerektirmeyen oyuncu bayrakları (admin bypass geçerli). */
    private boolean kontrolGenel(Player p, Bayrak b, Location l) {
        if (km.bypass(p)) return true;
        if (km.izinli(b, l)) return true;
        uyar(p, "&cBurada bu eylem yasak: &f" + b.ad);
        return false;
    }

    private Player kaynakOyuncu(Entity d) {
        if (d instanceof Player p) return p;
        if (d instanceof Projectile pr && pr.getShooter() instanceof Player p) return p;
        return null;
    }

    @EventHandler
    public void cikis(PlayerQuitEvent e) {
        sonMesaj.remove(e.getPlayer().getUniqueId());
        olumler.remove(e.getPlayer().getUniqueId());
        pl.alanGorevi().temizle(e.getPlayer());
    }

    // ------------------------------------------------------------ bloklar

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void blokKir(BlockBreakEvent e) {
        if (!kontrol(e.getPlayer(), Bayrak.BLOK_KIRMA, e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void blokKoy(BlockPlaceEvent e) {
        if (!kontrol(e.getPlayer(), Bayrak.BLOK_KOYMA, e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void kovaBosalt(PlayerBucketEmptyEvent e) {
        if (!kontrol(e.getPlayer(), Bayrak.KOVA, e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void kovaDoldur(PlayerBucketFillEvent e) {
        if (!kontrol(e.getPlayer(), Bayrak.KOVA, e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void etkilesim(PlayerInteractEvent e) {
        Block b = e.getClickedBlock();
        if (b == null) return;
        Player p = e.getPlayer();
        Action a = e.getAction();

        if (a == Action.PHYSICAL) {
            Material m = b.getType();
            if (m == Material.FARMLAND) {
                if (!km.bypass(p) && !km.izinli(Bayrak.TARLA_EZME, b.getLocation())) e.setCancelled(true);
            } else if (m == Material.TURTLE_EGG) {
                if (!km.karar(p, Bayrak.BLOK_KIRMA, b.getLocation()).izin()) e.setCancelled(true);
            } else if (Tag.PRESSURE_PLATES.isTagged(m) || m == Material.TRIPWIRE) {
                if (!km.karar(p, Bayrak.KULLANIM, b.getLocation()).izin()) e.setCancelled(true);
            }
            return;
        }
        if (a != Action.RIGHT_CLICK_BLOCK) return;

        Location l = b.getLocation();
        ItemStack it = e.getItem();
        // Eğilerek blok koyma: BlockPlaceEvent zaten kontrol ediyor.
        boolean yerlestiriyor = p.isSneaking() && it != null && it.getType().isBlock();
        if (!yerlestiriyor) {
            if (BlokTuru.konteyner(b)) {
                if (!kontrol(p, Bayrak.SANDIK_ACMA, l)) e.setCancelled(true);
                return;
            }
            if (BlokTuru.kullanilabilir(b)) {
                if (!kontrol(p, Bayrak.KULLANIM, l)) e.setCancelled(true);
                return;
            }
        }
        if (it != null && BlokTuru.yerlestirici(it.getType())) {
            if (!kontrol(p, Bayrak.BLOK_KOYMA, l)) e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------ varlıklar

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void varlikEtkilesim(PlayerInteractEntityEvent e) {
        Entity v = e.getRightClicked();
        Player p = e.getPlayer();
        Bayrak f = null;
        if (v instanceof ItemFrame || v instanceof ArmorStand) f = Bayrak.DEKOR;
        else if (v instanceof Vehicle && v instanceof InventoryHolder) f = Bayrak.SANDIK_ACMA; // sandıklı tekne, depolu/hunili vagon
        else if (v instanceof Vehicle) f = Bayrak.KULLANIM;
        else if (v instanceof Animals || v instanceof Tameable) f = Bayrak.HAYVAN_ZARAR;
        if (f != null && !kontrol(p, f, v.getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void zirhStandi(PlayerArmorStandManipulateEvent e) {
        if (!kontrol(e.getPlayer(), Bayrak.DEKOR, e.getRightClicked().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void cerceveKoy(HangingPlaceEvent e) {
        Player p = e.getPlayer();
        if (p != null && !kontrol(p, Bayrak.DEKOR, e.getEntity().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void cerceveKir(HangingBreakEvent e) {
        Location l = e.getEntity().getLocation();
        if (e instanceof HangingBreakByEntityEvent be) {
            Player p = kaynakOyuncu(be.getRemover());
            if (p != null) {
                if (!kontrol(p, Bayrak.DEKOR, l)) e.setCancelled(true);
                return;
            }
            if (be.getRemover() instanceof Creeper) {
                if (!km.izinli(Bayrak.CREEPER_PATLAMA, l)) e.setCancelled(true);
                return;
            }
        }
        if (e.getCause() == HangingBreakEvent.RemoveCause.EXPLOSION && !km.izinli(Bayrak.TNT_PATLAMA, l)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void hasarVarlik(EntityDamageByEntityEvent e) {
        Entity kurban = e.getEntity();
        Entity vuran = e.getDamager();
        Player saldirgan = kaynakOyuncu(vuran);

        if (kurban instanceof Player kp) {
            if (saldirgan != null) {
                if (saldirgan.equals(kp) || km.bypass(saldirgan)) return;
                if (!km.izinli(Bayrak.PVP, kp.getLocation()) || !km.izinli(Bayrak.PVP, saldirgan.getLocation())) {
                    e.setCancelled(true);
                    uyar(saldirgan, "&cBurada PvP kapalı!");
                }
            } else {
                boolean dusman = vuran instanceof Enemy
                        || (vuran instanceof Projectile pr && pr.getShooter() instanceof Enemy);
                if (dusman && !km.izinli(Bayrak.DUSMAN_HASAR, kp.getLocation())) e.setCancelled(true);
            }
            return;
        }

        if (saldirgan == null) return;
        Bayrak f = null;
        if (kurban instanceof Vehicle && kurban instanceof InventoryHolder) {
            f = Bayrak.SANDIK_ACMA;
        } else if (kurban instanceof ArmorStand || kurban instanceof Hanging || kurban instanceof Vehicle) {
            f = Bayrak.DEKOR;
        } else if (kurban instanceof LivingEntity && !(kurban instanceof Enemy)) {
            f = Bayrak.HAYVAN_ZARAR;
        }
        if (f != null && !kontrol(saldirgan, f, kurban.getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void hasarGenel(EntityDamageEvent e) {
        Entity en = e.getEntity();
        if (!(en instanceof Player p)) {
            EntityDamageEvent.DamageCause dc = e.getCause();
            if ((en instanceof ArmorStand || en instanceof Hanging || en instanceof Vehicle)
                    && (dc == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION || dc == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION)
                    && !km.izinli(Bayrak.TNT_PATLAMA, en.getLocation())) {
                e.setCancelled(true);
            }
            return;
        }
        EntityDamageEvent.DamageCause c = e.getCause();
        if (c == EntityDamageEvent.DamageCause.VOID || c == EntityDamageEvent.DamageCause.KILL
                || c == EntityDamageEvent.DamageCause.SUICIDE) {
            return;
        }
        Location l = p.getLocation();
        if (!km.izinli(Bayrak.OYUNCU_HASAR, l)) {
            e.setCancelled(true);
            return;
        }
        if (c == EntityDamageEvent.DamageCause.FALL && !km.izinli(Bayrak.DUSME_HASARI, l)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void aclik(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && e.getFoodLevel() < p.getFoodLevel()
                && !km.izinli(Bayrak.ACLIK, p.getLocation())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void olum(PlayerDeathEvent e) {
        olumler.put(e.getEntity().getUniqueId(), new Olum(e.getEntity().getLocation(), System.currentTimeMillis()));
    }

    /**
     * Claim içinde yerdeki eşya: sadece sahip/yetkili oyuncular alabilir ve atabilir.
     * İstisna: eşyayı kendisi attıysa ya da yakın zamanda orada öldüyse kendi eşyalarını geri alabilir.
     */
    private boolean claimEsyaIzni(Player p, Location l, Item esya) {
        if (l.getWorld() == null) return true;
        Object a = km.alanNesnesi(l.getWorld(), l.getBlockX(), l.getBlockY(), l.getBlockZ());
        if (!(a instanceof Claim c)) return true;
        UUID u = p.getUniqueId();
        if (c.herhangiYetki(u)) return true;
        if (esya != null && (u.equals(esya.getThrower()) || u.equals(esya.getOwner()))) return true;
        Olum o = olumler.get(u);
        return esya != null && o != null && System.currentTimeMillis() - o.zaman() < 300_000L
                && o.yer().getWorld() != null && o.yer().getWorld().equals(l.getWorld())
                && o.yer().distanceSquared(l) < 144;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void esyaAt(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        if (!kontrolGenel(p, Bayrak.ESYA_ATMA, p.getLocation())) {
            e.setCancelled(true);
            return;
        }
        if (!km.bypass(p) && !claimEsyaIzni(p, p.getLocation(), null)) {
            e.setCancelled(true);
            uyar(p, "&cBaşkasının claim'inde eşya atamazsın!");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void esyaAl(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p) || km.bypass(p)) return;
        Location l = p.getLocation();
        if (!km.izinli(Bayrak.ESYA_ALMA, l)) {
            e.setCancelled(true);
            return;
        }
        if (!claimEsyaIzni(p, l, e.getItem())) {
            e.setCancelled(true);
            uyar(p, "&cBu claim'deki eşyaları alamazsın!");
        }
    }

    // ------------------------------------------------------------ ok ile tetikleme / portal

    private boolean tetiklenebilir(Material m) {
        return Tag.BUTTONS.isTagged(m) || Tag.PRESSURE_PLATES.isTagged(m)
                || m == Material.TARGET || m == Material.BELL || m == Material.TRIPWIRE;
    }

    /** Okla düğme/hedef/çan tetikleme. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void okVurus(ProjectileHitEvent e) {
        Block b = e.getHitBlock();
        if (b == null || !(e.getEntity().getShooter() instanceof Player p)) return;
        if (tetiklenebilir(b.getType()) && !km.karar(p, Bayrak.KULLANIM, b.getLocation()).izin()) {
            e.setCancelled(true);
            e.getEntity().remove();
        }
    }

    /** Okun basınç plakası/tel tetiklemesi. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void okTetikleme(EntityInteractEvent e) {
        if (!(e.getEntity() instanceof Projectile pr) || !(pr.getShooter() instanceof Player p)) return;
        if (tetiklenebilir(e.getBlock().getType()) && !km.karar(p, Bayrak.KULLANIM, e.getBlock().getLocation()).izin()) {
            e.setCancelled(true);
        }
    }

    /** Portal, korumalı bir alana blok koyacaksa yetkisiz oyuncu için oluşmasın. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void portal(PortalCreateEvent e) {
        if (e.getReason() == PortalCreateEvent.CreateReason.END_PLATFORM) return;
        Player oyuncu = e.getEntity() instanceof Player pe ? pe : null;
        for (BlockState bs : e.getBlocks()) {
            Block b = bs.getBlock();
            if (km.alanNesnesi(b) == null) continue;
            if (oyuncu != null && km.karar(oyuncu, Bayrak.BLOK_KOYMA, b.getLocation()).izin()) continue;
            e.setCancelled(true);
            if (oyuncu != null) uyar(oyuncu, "&cPortal korumalı bir alana denk geliyor! Portalı başka yere kurup tekrar dene.");
            return;
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void isinlanma(PlayerTeleportEvent e) {
        PlayerTeleportEvent.TeleportCause c = e.getCause();
        if (c != PlayerTeleportEvent.TeleportCause.ENDER_PEARL && c != PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT) {
            return;
        }
        Location to = e.getTo();
        if (to != null && !kontrolGenel(e.getPlayer(), Bayrak.ENDER_INCI, to)) e.setCancelled(true);
    }

    // ------------------------------------------------------------ yıkım / doğa

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void patlama(EntityExplodeEvent e) {
        Bayrak f = e.getEntityType() == EntityType.CREEPER ? Bayrak.CREEPER_PATLAMA : Bayrak.TNT_PATLAMA;
        e.blockList().removeIf(b -> !km.izinli(f, b.getLocation()));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void blokPatlama(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> !km.izinli(Bayrak.TNT_PATLAMA, b.getLocation()));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void yanma(BlockBurnEvent e) {
        if (!km.izinli(Bayrak.YANGIN_YAYILMA, e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void tutusma(BlockIgniteEvent e) {
        Player p = e.getPlayer();
        if (p == null && e.getIgnitingEntity() instanceof Projectile pr && pr.getShooter() instanceof Player sp) p = sp;
        if (p != null) {
            if (!kontrol(p, Bayrak.BLOK_KOYMA, e.getBlock().getLocation())) e.setCancelled(true);
            return;
        }
        if (!km.izinli(Bayrak.YANGIN_YAYILMA, e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void mobBlok(EntityChangeBlockEvent e) {
        Entity ent = e.getEntity();
        if (ent instanceof FallingBlock || !(ent instanceof Mob)) return;
        if (ent instanceof Villager) return; // köylü tarımı zararsız
        Block b = e.getBlock();
        Bayrak f = b.getType() == Material.FARMLAND ? Bayrak.TARLA_EZME : Bayrak.MOB_BLOK_DEGISTIRME;
        if (!km.izinli(f, b.getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void mobDogma(CreatureSpawnEvent e) {
        LivingEntity en = e.getEntity();
        String sebep = e.getSpawnReason().name();
        Bayrak f = null;
        if (en instanceof Enemy) {
            if (DUSMAN_SEBEPLER.contains(sebep)) f = Bayrak.DUSMAN_MOB;
        } else if (en instanceof Animals) {
            if (HAYVAN_SEBEPLER.contains(sebep)) f = Bayrak.HAYVAN_DOGMA;
        }
        if (f != null && !km.izinli(f, e.getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void yaprak(LeavesDecayEvent e) {
        if (!km.izinli(Bayrak.YAPRAK_COKME, e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void erime(BlockFadeEvent e) {
        Material m = e.getBlock().getType();
        if ((m == Material.ICE || m == Material.SNOW || m == Material.SNOW_BLOCK)
                && !km.izinli(Bayrak.BUZ_ERIME, e.getBlock().getLocation())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void sivi(BlockFromToEvent e) {
        Block from = e.getBlock();
        if (!from.isLiquid()) return;
        Block to = e.getToBlock();
        if (!km.izinli(Bayrak.SIVI_AKIS, from.getLocation()) || !km.izinli(Bayrak.SIVI_AKIS, to.getLocation())) {
            e.setCancelled(true);
            return;
        }
        // Dışarıdan korumalı alana akışı engelle
        Object hedef = km.alanNesnesi(to);
        if (hedef != null && !km.ayniSahip(hedef, km.alanNesnesi(from))) e.setCancelled(true);
    }

    // ------------------------------------------------------------ piston / ağaç

    private boolean uyumlu(Object pistonAlani, Object hedef) {
        return hedef == null || km.ayniSahip(hedef, pistonAlani);
    }

    private boolean pistonGuvenli(Block piston, List<Block> bloklar, BlockFace yon) {
        Object pa = km.alanNesnesi(piston);
        for (Block b : bloklar) {
            if (!uyumlu(pa, km.alanNesnesi(b))) return false;
            if (!uyumlu(pa, km.alanNesnesi(b.getRelative(yon)))) return false;
            if (!uyumlu(pa, km.alanNesnesi(b.getRelative(yon.getOppositeFace())))) return false;
        }
        return true;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void pistonIt(BlockPistonExtendEvent e) {
        if (!pistonGuvenli(e.getBlock(), e.getBlocks(), e.getDirection())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void pistonCek(BlockPistonRetractEvent e) {
        if (!pistonGuvenli(e.getBlock(), e.getBlocks(), e.getDirection())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void agacBuyume(StructureGrowEvent e) {
        Object kaynak = km.alanNesnesi(e.getLocation().getBlock());
        e.getBlocks().removeIf(bs -> !uyumlu(kaynak, km.alanNesnesi(bs.getBlock())));
    }

    // ------------------------------------------------------------ huni / dağıtıcı / kova ile hayvan

    /** Huni, huni-vagon, düşürücü: korumalı alandan dışarı veya dışarıdan içeri eşya taşınmasın. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void envanterTasima(InventoryMoveItemEvent e) {
        Location k = e.getSource().getLocation();
        Location h = e.getDestination().getLocation();
        if (k == null || h == null || k.getWorld() == null || h.getWorld() == null) return;
        Object ka = km.alanNesnesi(k.getWorld(), k.getBlockX(), k.getBlockY(), k.getBlockZ());
        Object ha = km.alanNesnesi(h.getWorld(), h.getBlockX(), h.getBlockY(), h.getBlockZ());
        if (ka == ha || km.ayniSahip(ka, ha)) return;
        e.setCancelled(true);
    }

    /** Dışarıdaki dağıtıcı; su/lav/TNT/ateş/yumurta gibi şeyleri korumalı alana boşaltamasın. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void dagitici(BlockDispenseEvent e) {
        Block b = e.getBlock();
        if (!(b.getBlockData() instanceof Directional d)) return;
        Block hedef = b.getRelative(d.getFacing());
        Object ha = km.alanNesnesi(hedef);
        if (ha != null && !km.ayniSahip(ha, km.alanNesnesi(b))) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void kovaIleHayvan(PlayerBucketEntityEvent e) {
        if (!kontrol(e.getPlayer(), Bayrak.HAYVAN_ZARAR, e.getEntity().getLocation())) e.setCancelled(true);
    }

    // ------------------------------------------------------------ hava kilidi

    @EventHandler(ignoreCancelled = true)
    public void havaDegisim(WeatherChangeEvent e) {
        int v = km.dunyaDeger(e.getWorld(), Bayrak.HAVA);
        if (v < 0) return;
        boolean yagmura = e.toWeatherState();
        if (v == 0 && yagmura) e.setCancelled(true);
        if ((v == 1 || v == 2) && !yagmura) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void gokGurultusu(ThunderChangeEvent e) {
        int v = km.dunyaDeger(e.getWorld(), Bayrak.HAVA);
        if (v < 0) return;
        boolean firtina = e.toThunderState();
        if ((v == 0 || v == 1) && firtina) e.setCancelled(true);
        if (v == 2 && !firtina) e.setCancelled(true);
    }
}
