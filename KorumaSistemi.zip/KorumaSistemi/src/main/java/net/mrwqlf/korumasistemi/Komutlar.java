package net.mrwqlf.korumasistemi;

import org.bukkit.Bukkit;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class Komutlar implements CommandExecutor, TabCompleter {
    private final KorumaSistemi pl;
    private final KorumaYoneticisi km;

    public Komutlar(KorumaSistemi pl) {
        this.pl = pl;
        this.km = pl.yonetici();
    }

    private void m(CommandSender s, String t) {
        Yazi.mesaj(s, t);
    }

    private boolean admin(CommandSender s) {
        if (s.hasPermission("korumasistemi.admin")) return true;
        m(s, "&cBu komutu kullanmak için yetkin yok!");
        return false;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        switch (c.getName().toLowerCase(Locale.ROOT)) {
            case "protect" -> koruma(s, a);
            case "region" -> bolge(s, a);
            case "claim" -> claim(s, a);
            case "trust" -> trust(s, a);
            case "untrust" -> untrust(s, a);
            default -> { }
        }
        return true;
    }

    // =========================================================== /koruma

    private void koruma(CommandSender s, String[] a) {
        if (!admin(s)) return;
        String alt = a.length == 0 ? "panel" : a[0].toLowerCase(Locale.ROOT);
        switch (alt) {
            case "panel" -> {
                if (!(s instanceof Player p)) {
                    m(s, "&cBu komut sadece oyuncular içindir.");
                    return;
                }
                BayrakMenusu.ac(pl, p, km.dunya(p.getWorld()), null);
            }
            case "world" -> {
                if (!(s instanceof Player p)) {
                    m(s, "&cBu komut sadece oyuncular içindir.");
                    return;
                }
                if (a.length < 2) {
                    m(s, "&cKullanım: /protect world <dünya adı>");
                    return;
                }
                World w = Bukkit.getWorld(a[1]);
                if (w == null) {
                    m(s, "&cDünya bulunamadı: &f" + a[1]);
                    return;
                }
                BayrakMenusu.ac(pl, p, km.dunya(w), null);
            }
            case "bypass" -> {
                if (!(s instanceof Player p)) {
                    m(s, "&cBu komut sadece oyuncular içindir.");
                    return;
                }
                boolean acik = km.bypassDegistir(p);
                m(p, acik ? "&aKoruma bypass AÇIK &7— korumaları aşabilirsin."
                        : "&eKoruma bypass KAPALI &7— artık normal oyuncu gibi korumalara tabisin.");
            }
            case "info" -> {
                if (!(s instanceof Player p)) {
                    m(s, "&cBu komut sadece oyuncular içindir.");
                    return;
                }
                bilgiGoster(p);
            }
            case "clearsnow" -> {
                if (!(s instanceof Player p)) {
                    m(s, "&cBu komut sadece oyuncular içindir.");
                    return;
                }
                int r = 32;
                if (a.length >= 2) {
                    try {
                        r = Math.max(1, Math.min(128, Integer.parseInt(a[1])));
                    } catch (NumberFormatException ex) {
                        m(s, "&cYarıçap bir sayı olmalı (1-128).");
                        return;
                    }
                }
                m(p, "&aTemizlenen kar tabakası: &f" + karTemizle(p, r));
            }
            case "reload" -> {
                km.kaydet();
                pl.reloadConfig();
                km.yukle();
                m(s, "&aAyarlar ve veriler yeniden yüklendi.");
            }
            default -> {
                m(s, "&e/protect &7— dünya koruma paneli");
                m(s, "&e/protect world <ad> &7— başka dünyanın paneli");
                m(s, "&e/protect bypass &7— korumaları aşmayı aç/kapat");
                m(s, "&e/protect info &7— bulunduğun yerdeki etkin ayarlar");
                m(s, "&e/protect clearsnow [yarıçap] &7— biriken karı temizle");
                m(s, "&e/protect reload &7— ayarları yeniden yükle");
            }
        }
    }

    private void bilgiGoster(Player p) {
        Location l = p.getLocation();
        KorumaYoneticisi.AlanBilgi ab = km.alanBilgi(l);
        DunyaAyari d = km.dunya(p.getWorld());
        m(p, "&e&lKonum bilgisi");
        m(p, "&7Alan: " + (ab == null ? "&fkorumasız (sadece dünya kuralları)"
                : ab.claim() ? "&fClaim — " + ab.ad() : "&fBölge — " + ab.ad()));
        m(p, "&7Dünya koruması: " + (d.aktif ? "&aAÇIK" : "&cKAPALI") + " &7| Claim: " + (d.claimAcik ? "&aAÇIK" : "&cKAPALI"));
        StringBuilder yasak = new StringBuilder();
        for (Bayrak b : Bayrak.values()) {
            if (b.enumMi() || b.acikKapali) continue;
            if (!km.izinli(b, l)) yasak.append(b.ad).append(", ");
        }
        m(p, "&7Yasak olanlar: &c" + (yasak.length() == 0 ? "yok" : yasak.substring(0, yasak.length() - 2)));
        for (Bayrak b : new Bayrak[]{Bayrak.HAVA, Bayrak.ZAMAN, Bayrak.KAR}) {
            KorumaYoneticisi.EnumSonuc r = km.enumCoz(b, l);
            m(p, "&7" + b.ad + ": &f" + (r.var() ? b.secenekler[Math.min(r.deger(), b.secenekler.length - 1)]
                    + " &8(" + r.katman().ad + ")" : b.yokEtiketi()));
        }
        KorumaYoneticisi.EnumSonuc kb = km.enumCoz(Bayrak.KAR_BIRIKMESI, l);
        m(p, "&7Kar birikmesi: &f" + (kb.deger() == 1 ? "AÇIK" : "KAPALI"));
    }

    private int karTemizle(Player p, int r) {
        World w = p.getWorld();
        int px = p.getLocation().getBlockX(), pz = p.getLocation().getBlockZ();
        int sayac = 0;
        for (int x = px - r; x <= px + r; x++) {
            for (int z = pz - r; z <= pz + r; z++) {
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                Block ust = w.getHighestBlockAt(x, z, HeightMap.MOTION_BLOCKING);
                if (ust.getType() == Material.SNOW) {
                    ust.setType(Material.AIR, false);
                    sayac++;
                    continue;
                }
                Block ustu = ust.getRelative(0, 1, 0);
                if (ustu.getType() == Material.SNOW) {
                    ustu.setType(Material.AIR, false);
                    sayac++;
                }
            }
        }
        return sayac;
    }

    // =========================================================== /bolge

    private void bolgeYardim(CommandSender s) {
        m(s, "&e/region wand &7— seçim baltası al (sol=1., sağ=2. nokta)");
        m(s, "&e/region create <ad> [full] &7— seçimden bölge oluştur (full = tüm yükseklik)");
        m(s, "&e/region delete <ad> &7| &e/region list &7| &e/region info [ad]");
        m(s, "&e/region flag [ad] &7— bayrak paneli");
        m(s, "&e/region member add|remove <ad> <oyuncu> &7— bölge üyeleri (korumadan muaf)");
        m(s, "&e/region priority <ad> <sayı> &7| &e/region tp <ad>");
    }

    private Bolge bolgeBul(Player p, String ad) {
        if (ad != null) {
            Bolge b = km.bolgeAdla(p.getWorld().getUID(), ad);
            if (b == null) m(p, "&cBu dünyada &f" + ad + " &cadlı bölge yok.");
            return b;
        }
        Location l = p.getLocation();
        for (Bolge b : km.bolgeListesi(p.getWorld().getUID())) {
            if (b.icinde(l.getBlockX(), l.getBlockY(), l.getBlockZ())) return b;
        }
        m(p, "&cBir bölgenin içinde değilsin; bölge adı yaz.");
        return null;
    }

    private void bolge(CommandSender s, String[] a) {
        if (!admin(s)) return;
        if (!(s instanceof Player p)) {
            m(s, "&cBu komut sadece oyuncular içindir.");
            return;
        }
        if (a.length == 0) {
            bolgeYardim(p);
            return;
        }
        World w = p.getWorld();
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "wand" -> {
                p.getInventory().addItem(pl.baltaOlustur());
                m(p, "&aBölge baltası verildi. &7Sol tık: 1. nokta, sağ tık: 2. nokta.");
            }
            case "create" -> {
                if (a.length < 2) {
                    m(p, "&cKullanım: /region create <ad> [full]");
                    return;
                }
                String ad = a[1];
                if (!ad.matches("[\\p{L}\\p{N}_-]{1,24}")) {
                    m(p, "&cBölge adı 1-24 karakter olmalı; harf, rakam, _ ve - kullanılabilir.");
                    return;
                }
                if (km.bolgeAdla(w.getUID(), ad) != null) {
                    m(p, "&cBu adda bir bölge zaten var.");
                    return;
                }
                Location[] sc = pl.bolgeSecimi().al(p.getUniqueId());
                if (sc[0] == null || sc[1] == null) {
                    m(p, "&cÖnce &f/region wand &cile iki nokta seç.");
                    return;
                }
                if (!w.equals(sc[0].getWorld()) || !w.equals(sc[1].getWorld())) {
                    m(p, "&cSeçtiğin noktalar bu dünyada değil.");
                    return;
                }
                boolean tam = a.length >= 3 && a[2].equalsIgnoreCase("full");
                int minY = tam ? w.getMinHeight() : Math.min(sc[0].getBlockY(), sc[1].getBlockY());
                int maxY = tam ? w.getMaxHeight() - 1 : Math.max(sc[0].getBlockY(), sc[1].getBlockY());
                Bolge b = new Bolge(UUID.randomUUID(), ad, w.getUID(), w.getName(),
                        Math.min(sc[0].getBlockX(), sc[1].getBlockX()), minY, Math.min(sc[0].getBlockZ(), sc[1].getBlockZ()),
                        Math.max(sc[0].getBlockX(), sc[1].getBlockX()), maxY, Math.max(sc[0].getBlockZ(), sc[1].getBlockZ()));
                km.bolgeEkle(b);
                pl.bolgeSecimi().sil(p.getUniqueId());
                m(p, "&aBölge oluşturuldu: &f" + ad + " &7(" + b.hacim() + " blok). Üye olmayanlar artık burada inşa edemez.");
                m(p, "&7Bayrakları ayarlamak için: &f/region flag " + ad);
            }
            case "delete" -> {
                if (a.length < 2) {
                    m(p, "&cKullanım: /region delete <ad>");
                    return;
                }
                Bolge b = bolgeBul(p, a[1]);
                if (b == null) return;
                km.bolgeSil(b);
                m(p, "&eBölge silindi: &f" + b.ad);
            }
            case "list" -> {
                List<Bolge> l = km.bolgeListesi(w.getUID());
                if (l.isEmpty()) {
                    m(p, "&7Bu dünyada bölge yok.");
                    return;
                }
                m(p, "&e&lBölgeler &7(" + w.getName() + ")");
                for (Bolge b : l) m(p, "&f" + b.ad + " &7— öncelik " + b.oncelik + ", " + b.hacim() + " blok");
            }
            case "info" -> {
                Bolge b = bolgeBul(p, a.length >= 2 ? a[1] : null);
                if (b == null) return;
                m(p, "&e&lBölge: &f" + b.ad + " &7| öncelik " + b.oncelik);
                m(p, "&7X " + b.minX + "→" + b.maxX + " | Y " + b.minY + "→" + b.maxY + " | Z " + b.minZ + "→" + b.maxZ);
                List<String> adlar = new ArrayList<>();
                for (UUID u : b.uyeler) {
                    String n = Bukkit.getOfflinePlayer(u).getName();
                    adlar.add(n == null ? u.toString().substring(0, 8) : n);
                }
                m(p, "&7Üyeler: &f" + (adlar.isEmpty() ? "yok" : String.join(", ", adlar)));
                m(p, "&7Ayarlı bayrak sayısı: &f" + b.tumu().size());
            }
            case "flag" -> {
                Bolge b = bolgeBul(p, a.length >= 2 ? a[1] : null);
                if (b == null) return;
                BayrakMenusu.ac(pl, p, b, null);
            }
            case "member" -> {
                if (a.length < 4) {
                    m(p, "&cKullanım: /region member add|remove <bölge> <oyuncu>");
                    return;
                }
                Bolge b = bolgeBul(p, a[2]);
                if (b == null) return;
                OfflinePlayer op = oyuncuBul(a[3]);
                if (op == null) {
                    m(p, "&cOyuncu bulunamadı: &f" + a[3]);
                    return;
                }
                if (a[1].equalsIgnoreCase("add")) {
                    b.uyeler.add(op.getUniqueId());
                    m(p, "&a" + op.getName() + " &7artık &f" + b.ad + " &7bölgesinin üyesi.");
                } else if (a[1].equalsIgnoreCase("remove")) {
                    b.uyeler.remove(op.getUniqueId());
                    m(p, "&e" + op.getName() + " &7bölge üyeliğinden çıkarıldı.");
                } else {
                    m(p, "&cKullanım: /region member add|remove <bölge> <oyuncu>");
                    return;
                }
                km.kaydetPlanla();
            }
            case "priority" -> {
                if (a.length < 3) {
                    m(p, "&cKullanım: /region priority <ad> <sayı>");
                    return;
                }
                Bolge b = bolgeBul(p, a[1]);
                if (b == null) return;
                try {
                    b.oncelik = Integer.parseInt(a[2]);
                } catch (NumberFormatException ex) {
                    m(p, "&cÖncelik bir sayı olmalı.");
                    return;
                }
                km.bolgeSirala(b.dunya);
                km.kaydetPlanla();
                m(p, "&aÖncelik ayarlandı: &f" + b.oncelik);
            }
            case "tp" -> {
                if (a.length < 2) {
                    m(p, "&cKullanım: /region tp <ad>");
                    return;
                }
                Bolge b = bolgeBul(p, a[1]);
                if (b == null) return;
                int cx = (b.minX + b.maxX) / 2, cz = (b.minZ + b.maxZ) / 2;
                p.teleport(new Location(w, cx + 0.5, w.getHighestBlockYAt(cx, cz) + 1, cz + 0.5));
            }
            default -> bolgeYardim(p);
        }
    }

    // =========================================================== /claim

    private boolean sahipMi(Player p, Claim c) {
        return c.sahip.equals(p.getUniqueId()) || p.hasPermission("korumasistemi.admin");
    }

    private void claimYardim(Player p) {
        m(p, "&e/claim &7— claim menüsü (claim'in içindeyken)");
        m(p, "&e/claim shovel &7— altın kürek al");
        m(p, "&e/claim liste &7— claim'lerin");
        m(p, "&e/claim info &7| &e/claim border &7| &e/claim delete");
        m(p, "&e/trust <oyuncu|everyone> &7— yetki ekranı  &8|  &e/untrust <oyuncu|everyone>");
        m(p, "&7Claim atmak: altın küreğinle iki köşeye &fsağ tıkla&7.");
    }

    private void claim(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            m(s, "&cBu komut sadece oyuncular içindir.");
            return;
        }
        if (!p.hasPermission("korumasistemi.claim")) {
            m(p, "&cClaim kullanma yetkin yok!");
            return;
        }
        Location l = p.getLocation();
        Claim c = km.claimBul(l.getWorld().getUID(), l.getBlockX(), l.getBlockZ());
        String alt = a.length == 0 ? "menu" : a[0].toLowerCase(Locale.ROOT);
        switch (alt) {
            case "menu" -> {
                if (c == null) {
                    claimYardim(p);
                    return;
                }
                if (!sahipMi(p, c)) {
                    ClaimAraciDinleyici.bilgi(p, c);
                    return;
                }
                ClaimMenusu.ac(pl, p, c);
            }
            case "shovel" -> {
                ItemStack it = new ItemStack(Material.GOLDEN_SHOVEL);
                ItemMeta meta = it.getItemMeta();
                meta.displayName(Yazi.k("&6Claim Küreği"));
                meta.lore(List.of(Yazi.k("&7Sağ tık: köşe seç (2 köşe = claim)"),
                        Yazi.k("&7Eğil + sağ tık: seçimi iptal"),
                        Yazi.k("&7Eğil + sol tık: claim bilgisi")));
                it.setItemMeta(meta);
                p.getInventory().addItem(it);
                m(p, "&aClaim küreği verildi. &7İki köşeye sağ tıklayarak claim at.");
            }
            case "info" -> {
                if (c == null) {
                    m(p, "&7Burası bir claim değil.");
                    return;
                }
                ClaimAraciDinleyici.bilgi(p, c);
                Sinir.goster(pl, p, c);
            }
            case "border" -> {
                if (c == null) {
                    m(p, "&7Burası bir claim değil.");
                    return;
                }
                Sinir.goster(pl, p, c);
            }
            case "list" -> {
                UUID hedef = p.getUniqueId();
                if (a.length >= 2 && p.hasPermission("korumasistemi.admin")) {
                    OfflinePlayer op = oyuncuBul(a[1]);
                    if (op == null) {
                        m(p, "&cOyuncu bulunamadı: &f" + a[1]);
                        return;
                    }
                    hedef = op.getUniqueId();
                }
                List<Claim> l2 = km.oyuncuClaimleri(hedef);
                if (l2.isEmpty()) {
                    m(p, "&7Hiç claim yok.");
                    return;
                }
                m(p, "&e&lClaim listesi");
                for (Claim x : l2) {
                    m(p, "&f" + x.dunyaAdi + " &7X:" + x.minX + "→" + x.maxX + " Z:" + x.minZ + "→" + x.maxZ
                            + " &8(" + x.genislik() + "x" + x.uzunluk() + ")");
                }
            }
            case "delete" -> {
                if (c == null) {
                    m(p, "&cSilmek için silinecek claim'in içinde durmalısın.");
                    return;
                }
                if (!sahipMi(p, c)) {
                    m(p, "&cBu claim sana ait değil!");
                    return;
                }
                if (a.length < 2 || !a[1].equalsIgnoreCase("confirm")) {
                    m(p, "&cBu claim kalıcı olarak silinecek! Onaylamak için: &f/claim delete confirm");
                    return;
                }
                km.claimSil(c);
                m(p, "&eClaim silindi.");
            }
            default -> claimYardim(p);
        }
    }

    // =========================================================== /trust, /untrust

    private OfflinePlayer oyuncuBul(String ad) {
        Player on = Bukkit.getPlayerExact(ad);
        if (on != null) return on;
        return Bukkit.getOfflinePlayerIfCached(ad);
    }

    private Claim bulunduguClaim(Player p) {
        Location l = p.getLocation();
        Claim c = km.claimBul(l.getWorld().getUID(), l.getBlockX(), l.getBlockZ());
        if (c == null) {
            m(p, "&cBir claim'in içinde durmalısın. &7(Claim atmak için: /claim shovel)");
            return null;
        }
        if (!sahipMi(p, c)) {
            m(p, "&cBu claim sana ait değil!");
            return null;
        }
        return c;
    }

    private void trust(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            m(s, "&cBu komut sadece oyuncular içindir.");
            return;
        }
        if (!p.hasPermission("korumasistemi.claim")) {
            m(p, "&cClaim kullanma yetkin yok!");
            return;
        }
        if (a.length < 1) {
            m(p, "&cKullanım: /trust <oyuncu|everyone>");
            return;
        }
        Claim c = bulunduguClaim(p);
        if (c == null) return;
        UUID hedef;
        String ad;
        if (a[0].equalsIgnoreCase("everyone") || a[0].equalsIgnoreCase("herkes")) {
            hedef = Claim.HERKES;
            ad = "Herkes";
        } else {
            OfflinePlayer op = oyuncuBul(a[0]);
            if (op == null || op.getName() == null) {
                m(p, "&cOyuncu bulunamadı: &f" + a[0] + " &7(sunucuya hiç girmemiş olabilir)");
                return;
            }
            hedef = op.getUniqueId();
            ad = op.getName();
        }
        if (hedef.equals(c.sahip)) {
            m(p, "&cClaim sahibine yetki vermene gerek yok.");
            return;
        }
        TrustMenusu.ac(pl, p, c, hedef, ad);
    }

    private void untrust(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            m(s, "&cBu komut sadece oyuncular içindir.");
            return;
        }
        if (!p.hasPermission("korumasistemi.claim")) {
            m(p, "&cClaim kullanma yetkin yok!");
            return;
        }
        if (a.length < 1) {
            m(p, "&cKullanım: /untrust <oyuncu|everyone>");
            return;
        }
        Claim c = bulunduguClaim(p);
        if (c == null) return;
        UUID hedef;
        String ad;
        if (a[0].equalsIgnoreCase("everyone") || a[0].equalsIgnoreCase("herkes")) {
            hedef = Claim.HERKES;
            ad = "Herkes";
        } else {
            OfflinePlayer op = oyuncuBul(a[0]);
            if (op == null || op.getName() == null) {
                m(p, "&cOyuncu bulunamadı: &f" + a[0]);
                return;
            }
            hedef = op.getUniqueId();
            ad = op.getName();
        }
        if (c.guven.remove(hedef) != null) {
            km.kaydetPlanla();
            m(p, "&e" + ad + " &7artık bu claim'de hiçbir yetkiye sahip değil.");
        } else {
            m(p, "&7" + ad + " zaten yetkili değil.");
        }
    }

    // =========================================================== tab tamamlama

    private List<String> filtre(List<String> kaynak, String on) {
        List<String> r = new ArrayList<>();
        for (String x : kaynak) {
            if (x.toLowerCase(Locale.ROOT).startsWith(on.toLowerCase(Locale.ROOT))) r.add(x);
        }
        return r;
    }

    private List<String> oyuncular() {
        List<String> l = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) l.add(p.getName());
        return l;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        String ad = c.getName().toLowerCase(Locale.ROOT);
        switch (ad) {
            case "protect" -> {
                if (a.length == 1 && s.hasPermission("korumasistemi.admin")) {
                    return filtre(List.of("panel", "world", "bypass", "info", "clearsnow", "reload"), a[0]);
                }
                if (a.length == 2 && a[0].equalsIgnoreCase("world")) {
                    List<String> l = new ArrayList<>();
                    for (World w : Bukkit.getWorlds()) l.add(w.getName());
                    return filtre(l, a[1]);
                }
            }
            case "region" -> {
                if (!s.hasPermission("korumasistemi.admin")) return List.of();
                if (a.length == 1) {
                    return filtre(List.of("wand", "create", "delete", "list", "info", "flag", "member", "priority", "tp"), a[0]);
                }
                if (s instanceof Player p) {
                    String alt = a[0].toLowerCase(Locale.ROOT);
                    boolean adBekle = a.length == 2 && List.of("delete", "info", "flag", "priority", "tp").contains(alt);
                    boolean uyeAd = a.length == 3 && alt.equals("member");
                    if (adBekle || uyeAd) {
                        List<String> l = new ArrayList<>();
                        for (Bolge b : km.bolgeListesi(p.getWorld().getUID())) l.add(b.ad);
                        return filtre(l, a[a.length - 1]);
                    }
                    if (a.length == 2 && alt.equals("member")) return filtre(List.of("add", "remove"), a[1]);
                    if (a.length == 4 && alt.equals("member")) return filtre(oyuncular(), a[3]);
                    if (a.length == 3 && alt.equals("create")) return filtre(List.of("full"), a[2]);
                }
            }
            case "claim" -> {
                if (a.length == 1) return filtre(List.of("shovel", "info", "list", "border", "delete"), a[0]);
                if (a.length == 2 && a[0].equalsIgnoreCase("delete")) return filtre(List.of("confirm"), a[1]);
            }
            case "trust", "untrust" -> {
                if (a.length == 1) {
                    List<String> l = oyuncular();
                    l.add("everyone");
                    return filtre(l, a[0]);
                }
            }
            default -> { }
        }
        return List.of();
    }
}
