package net.mrwqlf.korumasistemi;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Dünya / bölge / claim bayraklarını düzenleyen panel. */
public final class BayrakMenusu extends Menu {
    private static final Bayrak[] TAM_KORUMA = {
            Bayrak.BLOK_KIRMA, Bayrak.BLOK_KOYMA, Bayrak.SANDIK_ACMA, Bayrak.KOVA, Bayrak.DEKOR,
            Bayrak.HAYVAN_ZARAR, Bayrak.PVP, Bayrak.CREEPER_PATLAMA, Bayrak.TNT_PATLAMA,
            Bayrak.YANGIN_YAYILMA, Bayrak.MOB_BLOK_DEGISTIRME, Bayrak.TARLA_EZME
    };

    private final KorumaSistemi pl;
    private final KorumaYoneticisi km;
    private final BayrakSahibi hedef;
    private final Runnable geri;
    private final List<Bayrak> liste;

    private BayrakMenusu(KorumaSistemi pl, BayrakSahibi hedef, Runnable geri) {
        this.pl = pl;
        this.km = pl.yonetici();
        this.hedef = hedef;
        this.geri = geri;
        int kapsam = switch (hedef.katman()) {
            case DUNYA -> Kapsam.D;
            case BOLGE -> Kapsam.B;
            case CLAIM -> Kapsam.C;
        };
        this.liste = Bayrak.kapsamdakiler(kapsam);
        this.env = Bukkit.createInventory(this, 54, Yazi.k("&8Koruma » " + hedef.baslik()));
    }

    public static void ac(KorumaSistemi pl, Player p, BayrakSahibi hedef, Runnable geri) {
        BayrakMenusu m = new BayrakMenusu(pl, hedef, geri);
        m.yenile();
        p.openInventory(m.env);
    }

    private boolean yetkili(Player p) {
        if (p.hasPermission("korumasistemi.admin")) return true;
        return hedef instanceof Claim c && c.sahip.equals(p.getUniqueId());
    }

    private String durum(Bayrak b) {
        Integer v = hedef.al(b);
        if (b.enumMi()) {
            return v == null ? "&7" + b.yokEtiketi() : "&b" + b.secenekler[Math.min(v, b.secenekler.length - 1)];
        }
        if (v != null) return v == 1 ? "&a" + b.izinEtiketi() : "&c" + b.yasakEtiketi();
        if (hedef.katman() == Katman.DUNYA) {
            return (b.varsayilan ? "&a" + b.izinEtiketi() : "&c" + b.yasakEtiketi()) + " &8(varsayılan)";
        }
        if (hedef.katman() == Katman.CLAIM && b.claimVarsayilan != null) {
            return "&7Varsayılan: " + (b.claimVarsayilan ? "&a" + b.izinEtiketi() : "&c" + b.yasakEtiketi());
        }
        return "&7Varsayılan &8(üst katmanı izler)";
    }

    private void yenile() {
        env.clear();
        for (int i = 0; i < liste.size() && i < 45; i++) {
            Bayrak b = liste.get(i);
            List<Component> lore = new ArrayList<>(Yazi.sar("&7", b.aciklama, 38));
            lore.add(Yazi.k(""));
            lore.add(Yazi.k("&fDurum: " + durum(b)));
            lore.add(Yazi.k(""));
            lore.add(Yazi.k("&8▸ &7Tıkla: &fdeğiştir"));
            lore.add(Yazi.k("&8▸ &7Shift+Tıkla: &fvarsayılana döndür"));
            env.setItem(i, esya(b.ikon, "&e" + b.ad, lore));
        }

        if (hedef instanceof DunyaAyari d) {
            env.setItem(45, esya(Material.SHIELD, "&a&lTAM KORUMA",
                    "&7Blok kırma/koyma, sandık, kova, çerçeve,", "&7hayvan, PvP, patlama, yangın, mob zararı",
                    "&7ve tarla çiğnemeyi &cyasaklar&7.", "", "&8▸ &7Tıkla: &fuygula"));
            env.setItem(46, esya(Material.MILK_BUCKET, "&e&lHEPSİNİ SERBEST BIRAK",
                    "&7Bu dünyadaki tüm bayrak ayarlarını", "&7sıfırlar (her şey serbest).", "", "&8▸ &7Tıkla: &fsıfırla"));
            env.setItem(47, esya(Material.GOLDEN_SHOVEL, "&6Claim Sistemi: " + (d.claimAcik ? "&aAÇIK" : "&cKAPALI"),
                    "&7Oyuncular bu dünyada altın küreğle", "&7claim atabilsin mi?", "", "&8▸ &7Tıkla: &fdeğiştir"));
            env.setItem(48, esya(d.aktif ? Material.LIME_DYE : Material.GRAY_DYE,
                    "&bDünya Koruması: " + (d.aktif ? "&aAÇIK" : "&cKAPALI"),
                    "&7Kapalıyken dünya bayrakları yok sayılır;", "&7bölge ve claim'ler çalışmaya devam eder.", "",
                    "&8▸ &7Tıkla: &fdeğiştir"));
            env.setItem(49, esya(Material.PAPER, "&f" + d.dunyaAdi, "&7Düzenlenen dünya"));
            env.setItem(50, esya(Material.COMPASS, "&dSonraki Dünya", "&7Başka bir dünyanın ayarlarına geç.", "",
                    "&8▸ &7Tıkla: &fdeğiştir"));
        } else {
            env.setItem(45, esya(Material.MILK_BUCKET, "&e&lHEPSİNİ VARSAYILANA DÖNDÜR", "&7Tüm bayrak ayarlarını temizler."));
            env.setItem(49, esya(Material.PAPER, "&f" + hedef.baslik()));
            if (geri != null) env.setItem(52, esya(Material.ARROW, "&7« Geri"));
        }
        env.setItem(53, esya(Material.BARRIER, "&cKapat"));
    }

    @Override
    public void tikla(InventoryClickEvent e) {
        Player p = (Player) e.getWhoClicked();
        if (!yetkili(p)) {
            p.closeInventory();
            return;
        }
        int s = e.getSlot();
        if (s < liste.size() && s < 45) {
            degistir(liste.get(s), e.getClick().isShiftClick());
            km.kaydetPlanla();
            yenile();
            return;
        }
        if (s == 53) {
            p.closeInventory();
            return;
        }
        if (s == 52 && geri != null && !(hedef instanceof DunyaAyari)) {
            geri.run();
            return;
        }
        if (hedef instanceof DunyaAyari d) {
            switch (s) {
                case 45 -> {
                    for (Bayrak b : TAM_KORUMA) d.koy(b, 0);
                    Yazi.mesaj(p, "&aTam koruma uygulandı: &f" + d.dunyaAdi);
                }
                case 46 -> {
                    d.tumu().clear();
                    Yazi.mesaj(p, "&eTüm bayraklar sıfırlandı: &f" + d.dunyaAdi);
                }
                case 47 -> d.claimAcik = !d.claimAcik;
                case 48 -> d.aktif = !d.aktif;
                case 50 -> {
                    List<World> ws = Bukkit.getWorlds();
                    int idx = 0;
                    for (int i = 0; i < ws.size(); i++) {
                        if (ws.get(i).getName().equals(d.dunyaAdi)) idx = i;
                    }
                    World sonraki = ws.get((idx + 1) % ws.size());
                    km.kaydetPlanla();
                    ac(pl, p, km.dunya(sonraki), null);
                    return;
                }
                default -> {
                    return;
                }
            }
            km.kaydetPlanla();
            yenile();
        } else if (s == 45) {
            hedef.tumu().clear();
            km.kaydetPlanla();
            yenile();
        }
    }

    private void degistir(Bayrak b, boolean sifirla) {
        Integer v = hedef.al(b);
        if (sifirla) {
            hedef.sil(b);
            return;
        }
        if (b.enumMi()) {
            int n = b.secenekler.length;
            if (v == null) hedef.koy(b, 0);
            else if (v + 1 >= n) hedef.sil(b);
            else hedef.koy(b, v + 1);
        } else if (hedef.katman() == Katman.DUNYA) {
            boolean mevcut = v == null ? b.varsayilan : v == 1;
            hedef.koy(b, mevcut ? 0 : 1);
        } else {
            if (v == null) hedef.koy(b, 0);
            else if (v == 0) hedef.koy(b, 1);
            else hedef.sil(b);
        }
    }
}
