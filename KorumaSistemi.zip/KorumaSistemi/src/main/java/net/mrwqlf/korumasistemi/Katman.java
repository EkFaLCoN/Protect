package net.mrwqlf.korumasistemi;

public enum Katman {
    BOLGE("Bölge"), CLAIM("Claim"), DUNYA("Dünya");

    public final String ad;

    Katman(String ad) {
        this.ad = ad;
    }
}
