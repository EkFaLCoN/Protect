package net.mrwqlf.korumasistemi;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import net.kyori.adventure.text.Component;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

/** /trust sonrası açılan "hangi yetkileri vermek istersin?" ekranı. */
public final class TrustMenusu extends Menu {
    private static final int[] YETKI_SLOTLARI = {10, 11, 12, 13, 14, 15, 16};

    private final KorumaSistemi pl;
    private final Claim claim;
    private final UUID hedefId;
    private final String hedefAd;

    private TrustMenusu(KorumaSistemi pl, Claim claim, UUID hedefId, String hedefAd) {
        this.pl = pl;
        this.claim = claim;
        this.hedefId = hedefId;
        this.hedefAd = hedefAd;
        this.env = Bukkit.createInventory(this, 27, Yazi.k("&8Yetkiler » " + hedefAd));
    }

    public static void ac(KorumaSistemi pl, Player p, Claim claim, UUID hedefId, String hedefAd) {
        TrustMenusu m = new TrustMenusu(pl, claim, hedefId, hedefAd);
        m.yenile();
        p.openInventory(m.env);
    }

    private boolean yetkili(Player p) {
        return claim.sahip.equals(p.getUniqueId()) || p.hasPermission("korumasistemi.admin");
    }

    private EnumSet<TrustYetki> set() {
        EnumSet<TrustYetki> s = claim.guven.get(hedefId);
        return s == null ? EnumSet.noneOf(TrustYetki.class) : s;
    }

    private void yenile() {
        env.clear();
        EnumSet<TrustYetki> mevcut = set();

        ItemStack kafa;
        if (hedefId.equals(Claim.HERKES)) {
            kafa = esya(Material.NETHER_STAR, "&e" + hedefAd, "&7Bu yetkiler sunucudaki &fher oyuncuya &7verilir.");
        } else {
            kafa = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) kafa.getItemMeta();
            sm.setOwningPlayer(Bukkit.getOfflinePlayer(hedefId));
            sm.displayName(Yazi.k("&e" + hedefAd));
            List<Component> lore = new ArrayList<>();
            lore.add(Yazi.k("&7Hangi yetkileri vermek istersin?"));
            sm.lore(lore);
            kafa.setItemMeta(sm);
        }
        env.setItem(4, kafa);

        TrustYetki[] hepsi = TrustYetki.values();
        for (int i = 0; i < hepsi.length; i++) {
            TrustYetki t = hepsi[i];
            boolean var = mevcut.contains(t);
            List<Component> lore = new ArrayList<>(Yazi.sar("&7", t.aciklama, 38));
            lore.add(Yazi.k(""));
            lore.add(Yazi.k(var ? "&a✔ VERİLDİ" : "&c✘ VERİLMEDİ"));
            lore.add(Yazi.k("&8▸ &7Tıkla: &fdeğiştir"));
            env.setItem(YETKI_SLOTLARI[i], esya(t.ikon, (var ? "&a" : "&c") + t.ad, lore));
        }

        env.setItem(18, esya(Material.LIME_DYE, "&a&lTÜMÜNÜ VER", "&7Bütün yetkileri ver (tam güven)."));
        env.setItem(22, esya(Material.EMERALD, "&a&lKAYDET VE KAPAT", "&7Değişiklikler zaten anında uygulanır."));
        env.setItem(26, esya(Material.RED_DYE, "&c&lTÜMÜNÜ AL", "&7Bütün yetkileri geri al."));
    }

    @Override
    public void tikla(InventoryClickEvent e) {
        Player p = (Player) e.getWhoClicked();
        if (!yetkili(p)) {
            p.closeInventory();
            return;
        }
        int s = e.getSlot();
        TrustYetki[] hepsi = TrustYetki.values();
        for (int i = 0; i < hepsi.length; i++) {
            if (YETKI_SLOTLARI[i] == s) {
                EnumSet<TrustYetki> set = claim.guven.computeIfAbsent(hedefId, k -> EnumSet.noneOf(TrustYetki.class));
                if (!set.remove(hepsi[i])) set.add(hepsi[i]);
                if (set.isEmpty()) claim.guven.remove(hedefId);
                pl.yonetici().kaydetPlanla();
                yenile();
                return;
            }
        }
        switch (s) {
            case 18 -> {
                claim.guven.put(hedefId, EnumSet.allOf(TrustYetki.class));
                pl.yonetici().kaydetPlanla();
                yenile();
            }
            case 26 -> {
                claim.guven.remove(hedefId);
                pl.yonetici().kaydetPlanla();
                yenile();
            }
            case 22 -> {
                p.closeInventory();
                int adet = set().size();
                Yazi.mesaj(p, adet == 0 ? "&e" + hedefAd + " &7artık hiçbir yetkiye sahip değil."
                        : "&e" + hedefAd + " &7için &f" + adet + " &7yetki kaydedildi.");
            }
            default -> { }
        }
    }
}
