package net.mrwqlf.korumasistemi;

import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.ItemFlag;
import net.kyori.adventure.text.Component;

import java.util.ArrayList;
import java.util.List;

public abstract class Menu implements InventoryHolder {
    protected Inventory env;

    @Override
    public Inventory getInventory() {
        return env;
    }

    public abstract void tikla(InventoryClickEvent e);

    protected static ItemStack esya(Material m, String ad, List<Component> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Yazi.k(ad));
        meta.lore(new ArrayList<>(lore));
        meta.addItemFlags(ItemFlag.values());
        it.setItemMeta(meta);
        return it;
    }

    protected static ItemStack esya(Material m, String ad, String... satirlar) {
        List<Component> l = new ArrayList<>();
        for (String s : satirlar) l.add(Yazi.k(s));
        return esya(m, ad, l);
    }
}
