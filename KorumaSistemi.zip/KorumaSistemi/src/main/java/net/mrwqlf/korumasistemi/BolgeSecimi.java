package net.mrwqlf.korumasistemi;

import org.bukkit.Location;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Bölge baltasıyla seçilen iki köşe noktası. */
public final class BolgeSecimi {
    private final Map<UUID, Location[]> secimler = new HashMap<>();

    public Location[] al(UUID u) {
        return secimler.computeIfAbsent(u, k -> new Location[2]);
    }

    public void sil(UUID u) {
        secimler.remove(u);
    }
}
