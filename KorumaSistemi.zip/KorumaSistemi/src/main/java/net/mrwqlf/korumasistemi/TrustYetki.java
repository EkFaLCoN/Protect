package net.mrwqlf.korumasistemi;

import org.bukkit.Material;

/** Claim sahibinin güvendiği oyunculara verebileceği yetkiler. */
public enum TrustYetki {
    KIRMA("Blok Kırma", Material.IRON_PICKAXE, "Claim içindeki blokları kırabilir."),
    KOYMA("Blok Koyma", Material.GRASS_BLOCK, "Claim içine blok koyabilir, ateş yakabilir."),
    KULLANIM("Kapı / Düğme / Kaldıraç", Material.OAK_DOOR, "Kapı, düğme, kaldıraç, basınç plakası ve yatak gibi blokları kullanabilir."),
    SANDIK("Sandık ve Konteynerler", Material.CHEST, "Sandık, fırın, varil, huni gibi envanterli blokları açabilir."),
    KOVA("Kova Kullanma", Material.BUCKET, "Su ve lav kovası kullanabilir."),
    DEKOR("Çerçeve / Zırh Standı", Material.ITEM_FRAME, "Eşya çerçevesi, tablo ve zırh standını değiştirebilir."),
    HAYVAN("Hayvanlar", Material.BEEF, "Hayvanlara zarar verebilir, üretebilir, bağlayabilir.");

    public final String ad;
    public final Material ikon;
    public final String aciklama;

    TrustYetki(String ad, Material ikon, String aciklama) {
        this.ad = ad;
        this.ikon = ikon;
        this.aciklama = aciklama;
    }
}
