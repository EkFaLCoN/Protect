package net.mrwqlf.korumasistemi;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Altın kürek (claim) ve bölge baltası (admin seçimi) kullanımı. */
public final class ClaimAraciDinleyici implements Listener {
    private record Secim(UUID dunya, int x, int y, int z, long zaman) {}

    private final KorumaSistemi pl;
    private final KorumaYoneticisi km;
    private final Map<UUID, Secim> secimler = new HashMap<>();

    public ClaimAraciDinleyici(KorumaSistemi pl) {
        this.pl = pl;
        this.km = pl.yonetici();
    }

    @EventHandler
    public void cikis(PlayerQuitEvent e) {
        secimler.remove(e.getPlayer().getUniqueId());
        pl.bolgeSecimi().sil(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void arac(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        ItemStack it = e.getItem();
        if (it == null) return;
        Player p = e.getPlayer();
        if (it.getType() == Material.GOLDEN_SHOVEL) {
            kurek(e, p);
        } else if (it.getType() == Material.WOODEN_AXE && pl.baltaMi(it) && p.hasPermission("korumasistemi.admin")) {
            balta(e, p);
        }
    }

    // ------------------------------------------------------------ bölge baltası

    private void balta(PlayerInteractEvent e, Player p) {
        Action a = e.getAction();
        Block b = e.getClickedBlock();
        if (b == null || (a != Action.LEFT_CLICK_BLOCK && a != Action.RIGHT_CLICK_BLOCK)) return;
        e.setCancelled(true);
        Location[] sc = pl.bolgeSecimi().al(p.getUniqueId());
        int i = a == Action.LEFT_CLICK_BLOCK ? 0 : 1;
        sc[i] = b.getLocation();
        Yazi.mesaj(p, "&a" + (i + 1) + ". nokta seçildi: &f" + b.getX() + ", " + b.getY() + ", " + b.getZ()
                + (sc[0] != null && sc[1] != null ? " &7— şimdi &f/region create <ad> [full]" : ""));
    }

    // ------------------------------------------------------------ altın kürek

    private void kurek(PlayerInteractEvent e, Player p) {
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_BLOCK && !(a == Action.LEFT_CLICK_BLOCK && p.isSneaking())) return;
        Block b = e.getClickedBlock();
        if (b == null) return;
        World w = b.getWorld();
        if (!km.dunya(w).claimAcik) return;           // claim kapalıysa kürek normal çalışır
        if (!p.hasPermission("korumasistemi.claim")) return;
        e.setCancelled(true);

        Claim mevcut = km.claimBul(w.getUID(), b.getX(), b.getZ());

        if (a == Action.LEFT_CLICK_BLOCK) {
            if (mevcut == null) {
                Yazi.mesaj(p, "&7Burası claim değil. Sağ tıkla köşe seçerek claim atabilirsin.");
            } else {
                bilgi(p, mevcut);
                Sinir.goster(pl, p, mevcut);
            }
            return;
        }

        if (p.isSneaking()) {
            secimler.remove(p.getUniqueId());
            Yazi.mesaj(p, "&7Claim seçimi temizlendi.");
            return;
        }

        Secim s = secimler.get(p.getUniqueId());
        long simdi = System.currentTimeMillis();
        boolean gecerli = s != null && s.dunya().equals(w.getUID()) && simdi - s.zaman() < 5 * 60_000L;

        if (!gecerli) {
            if (mevcut != null) {
                bilgi(p, mevcut);
                Sinir.goster(pl, p, mevcut);
                return;
            }
            secimler.put(p.getUniqueId(), new Secim(w.getUID(), b.getX(), b.getY(), b.getZ(), simdi));
            Sinir.isaret(pl, p, b.getX(), b.getY(), b.getZ());
            Yazi.mesaj(p, "&a1. köşe seçildi: &f" + b.getX() + ", " + b.getZ()
                    + "&7. Şimdi karşı köşeye altın küreğinle &fsağ tıkla&7. (İptal: eğilip sağ tık)");
            return;
        }

        secimler.remove(p.getUniqueId());
        olustur(p, w, s, b.getX(), b.getZ());
    }

    private void olustur(Player p, World w, Secim s, int x2, int z2) {
        UUID wid = w.getUID();
        int minX = Math.min(s.x(), x2), maxX = Math.max(s.x(), x2);
        int minZ = Math.min(s.z(), z2), maxZ = Math.max(s.z(), z2);
        int gen = maxX - minX + 1, uz = maxZ - minZ + 1;
        long alan = (long) gen * uz;

        int minKenar = pl.getConfig().getInt("claim.en-kucuk-kenar", 5);
        if (gen < minKenar || uz < minKenar) {
            Yazi.mesaj(p, "&cClaim çok küçük! Her kenar en az &f" + minKenar + " &cblok olmalı. (Seçtiğin: " + gen + "x" + uz + ")");
            return;
        }

        boolean sinirsiz = p.hasPermission("korumasistemi.sinirsiz") || p.hasPermission("korumasistemi.admin");
        List<Claim> benimkiler = km.oyuncuClaimleri(p.getUniqueId());
        long toplam = 0;
        for (Claim c : benimkiler) toplam += c.alan();
        int maksSayi = pl.getConfig().getInt("claim.en-fazla-sayi", 50);
        long maksAlan = pl.getConfig().getLong("claim.en-fazla-toplam-alan", 1000L);
        if (!sinirsiz) {
            if (benimkiler.size() >= maksSayi) {
                Yazi.mesaj(p, "&cEn fazla &f" + maksSayi + " &cclaim'in olabilir. Birini silmek için: &f/claim delete");
                return;
            }
            if (toplam + alan > maksAlan) {
                Yazi.mesaj(p, "&cToplam claim alanın aşılıyor! Kalan hakkın: &f" + Math.max(0, maksAlan - toplam)
                        + " &cblok, seçtiğin: &f" + alan);
                return;
            }
        }

        for (Bolge bo : km.bolgeListesi(wid)) {
            if (bo.kesisirXZ(minX, minZ, maxX, maxZ)) {
                Yazi.mesaj(p, "&cBu alan yönetici bölgesiyle çakışıyor: &f" + bo.ad);
                return;
            }
        }
        for (Claim c : km.claimler()) {
            if (c.dunya.equals(wid) && c.kesisir(minX, minZ, maxX, maxZ)) {
                Yazi.mesaj(p, "&cBu alan &f" + c.sahipAdi + " &coyuncusunun claim'i ile çakışıyor!");
                Sinir.goster(pl, p, c);
                return;
            }
        }

        Claim yeni = new Claim(UUID.randomUUID(), p.getUniqueId(), p.getName(), wid, w.getName(),
                minX, minZ, maxX, maxZ, System.currentTimeMillis());
        km.claimEkle(yeni);
        Yazi.mesaj(p, "&aClaim oluşturuldu! &7Boyut: &f" + gen + "x" + uz + " &7(" + alan + " blok)");
        if (!sinirsiz) {
            Yazi.mesaj(p, "&7Kalan alan hakkın: &f" + Math.max(0, maksAlan - toplam - alan) + " &7blok");
        }
        Yazi.mesaj(p, "&7Arkadaşlarına yetki vermek için: &f/trust <oyuncu> &7— Menü için: &f/claim");
        Sinir.goster(pl, p, yeni);
    }

    public static void bilgi(Player p, Claim c) {
        Yazi.mesaj(p, "&eClaim sahibi: &f" + c.sahipAdi + " &7| Boyut: &f" + c.genislik() + "x" + c.uzunluk()
                + " &7| Güvenilen: &f" + c.guven.size());
    }
}
