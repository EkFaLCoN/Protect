package net.mrwqlf.korumasistemi;

import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.Container;

/** Etkileşim korumasında kullanılan blok/eşya sınıflandırması. */
public final class BlokTuru {
    private BlokTuru() {}

    public static boolean konteyner(Block b) {
        if (b.getType() == Material.ENDER_CHEST) return false; // kişisel, güvenli
        return b.getState(false) instanceof Container;
    }

    public static boolean kullanilabilir(Block b) {
        Material m = b.getType();
        if (Tag.DOORS.isTagged(m) || Tag.TRAPDOORS.isTagged(m) || Tag.FENCE_GATES.isTagged(m)
                || Tag.BUTTONS.isTagged(m) || Tag.BEDS.isTagged(m) || Tag.ANVIL.isTagged(m)
                || Tag.ALL_SIGNS.isTagged(m) || Tag.CAULDRONS.isTagged(m) || Tag.CANDLE_CAKES.isTagged(m)
                || Tag.CAMPFIRES.isTagged(m)) {
            return true;
        }
        if (m == Material.FLOWER_POT || m.name().startsWith("POTTED_")) return true;
        return switch (m) {
            case LEVER, NOTE_BLOCK, REPEATER, COMPARATOR, DAYLIGHT_DETECTOR, BELL, COMPOSTER, CAKE,
                 JUKEBOX, RESPAWN_ANCHOR, DRAGON_EGG, BEEHIVE, BEE_NEST, SWEET_BERRY_BUSH,
                 CAVE_VINES, CAVE_VINES_PLANT, DECORATED_POT -> true;
            default -> false;
        };
    }

    /** Tıklanan bloğa uygulanınca dünyayı değiştiren eşyalar (yumurta, tekne, çapa, kemik tozu...). */
    public static boolean yerlestirici(Material m) {
        String n = m.name();
        return n.endsWith("_SPAWN_EGG") || n.endsWith("_BOAT") || n.endsWith("_RAFT") || n.endsWith("MINECART")
                || n.endsWith("_HOE") || n.endsWith("_AXE") || n.endsWith("_SHOVEL")
                || m == Material.ARMOR_STAND || m == Material.END_CRYSTAL || m == Material.FLINT_AND_STEEL
                || m == Material.FIRE_CHARGE || m == Material.BONE_MEAL || m == Material.HONEYCOMB;
    }
}
