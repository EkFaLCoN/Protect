package net.mrwqlf.korumasistemi;

import net.mrwqlf.korumasistemi.KorumaYoneticisi.AlanBilgi;
import net.mrwqlf.korumasistemi.KorumaYoneticisi.EnumSonuc;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.WeatherType;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Her oyuncu için: korumalı alana giriş/çıkış mesajı, bölge/claim içi hava-zaman
 * ayarı (oyuncuya özel) ve kar seviyesi hesabı.
 */
public final class AlanGorevi implements Runnable {
    private static final long[] ZAMANLAR = {6000L, 12500L, 18000L};

    private final KorumaYoneticisi km;
    private final Map<UUID, String> sonAlan = new HashMap<>();
    private final Map<UUID, WeatherType> havaZorla = new HashMap<>();
    private final Map<UUID, Long> zamanZorla = new HashMap<>();
    /** [kar seviyesi (-1 = kapalı), birikme (0/1)] */
    private final Map<UUID, int[]> kar = new HashMap<>();

    public AlanGorevi(KorumaSistemi pl) {
        this.km = pl.yonetici();
    }

    public int[] karDurumu(UUID u) {
        return kar.get(u);
    }

    public void temizle(Player p) {
        UUID u = p.getUniqueId();
        sonAlan.remove(u);
        kar.remove(u);
        if (havaZorla.remove(u) != null) p.resetPlayerWeather();
        if (zamanZorla.remove(u) != null) p.resetPlayerTime();
    }

    public void hepsiniTemizle() {
        for (Player p : Bukkit.getOnlinePlayers()) temizle(p);
    }

    @Override
    public void run() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            try {
                isle(p);
            } catch (RuntimeException ex) {
                // tek oyuncudaki hata diğerlerini etkilemesin
            }
        }
    }

    private void isle(Player p) {
        UUID u = p.getUniqueId();
        Location l = p.getLocation();

        // --- giriş / çıkış mesajı
        AlanBilgi ab = km.alanBilgi(l);
        String yeni = ab == null ? "" : ab.anahtar();
        String eski = sonAlan.getOrDefault(u, "");
        if (!yeni.equals(eski)) {
            sonAlan.put(u, yeni);
            if (ab == null) {
                Yazi.aksiyon(p, "&7◀ Korumalı alandan ayrıldın");
            } else if (ab.claim()) {
                Yazi.aksiyon(p, u.equals(ab.sahip()) ? "&a▶ Kendi claim'indesin"
                        : "&e▶ &f" + ab.ad() + " &eoyuncusunun claim'ine girdin");
            } else {
                Yazi.aksiyon(p, "&b▶ Bölge: &f" + ab.ad());
            }
        }

        // --- hava / zaman / kar
        EnumSonuc hava = km.enumCoz(Bayrak.HAVA, l);
        EnumSonuc zaman = km.enumCoz(Bayrak.ZAMAN, l);
        EnumSonuc karS = km.enumCoz(Bayrak.KAR, l);
        EnumSonuc birikme = km.enumCoz(Bayrak.KAR_BIRIKMESI, l);

        kar.put(u, new int[]{karS.deger(), birikme.deger() == 1 ? 1 : 0});

        WeatherType istenenHava = null;
        if (hava.var() && hava.katman() != Katman.DUNYA) {
            istenenHava = hava.deger() == 0 ? WeatherType.CLEAR : WeatherType.DOWNFALL;
        } else if (karS.var()) {
            istenenHava = WeatherType.CLEAR; // yağmur çizgileri yerine kar parçacıkları görünsün
        }
        WeatherType mevcutHava = havaZorla.get(u);
        if (istenenHava == null) {
            if (mevcutHava != null) {
                p.resetPlayerWeather();
                havaZorla.remove(u);
            }
        } else if (istenenHava != mevcutHava) {
            p.setPlayerWeather(istenenHava);
            havaZorla.put(u, istenenHava);
        }

        Long istenenZaman = null;
        if (zaman.var() && zaman.katman() != Katman.DUNYA && zaman.deger() < ZAMANLAR.length) {
            istenenZaman = ZAMANLAR[zaman.deger()];
        }
        Long mevcutZaman = zamanZorla.get(u);
        if (istenenZaman == null) {
            if (mevcutZaman != null) {
                p.resetPlayerTime();
                zamanZorla.remove(u);
            }
        } else if (!istenenZaman.equals(mevcutZaman)) {
            p.setPlayerTime(istenenZaman, false);
            zamanZorla.put(u, istenenZaman);
        }
    }
}
