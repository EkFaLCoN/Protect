package net.mrwqlf.korumasistemi;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Claim'de yetkisi olan oyuncuların listesi. */
public final class GuvenListesiMenusu extends Menu {
    private final KorumaSistemi pl;
    private final Claim claim;
    private final List<UUID> sira = new ArrayList<>();

    private GuvenListesiMenusu(KorumaSistemi pl, Claim claim) {
        this.pl = pl;
        this.claim = claim;
        this.env = Bukkit.createInventory(this, 54, Yazi.k("&8Güvenilenler » " + claim.sahipAdi));
    }

    public static void ac(KorumaSistemi pl, Player p, Claim claim) {
        GuvenListesiMenusu m = new GuvenListesiMenusu(pl, claim);
        m.yenile();
        p.openInventory(m.env);
    }

    private static String ad(UUID u) {
        if (u.equals(Claim.HERKES)) return "Herkes";
        OfflinePlayer op = Bukkit.getOfflinePlayer(u);
        return op.getName() != null ? op.getName() : u.toString().substring(0, 8);
    }

    private void yenile() {
        env.clear();
        sira.clear();
        int i = 0;
        for (Map.Entry<UUID, EnumSet<TrustYetki>> e : claim.guven.entrySet()) {
            if (i >= 45) break;
            UUID u = e.getKey();
            sira.add(u);
            List<Component> lore = new ArrayList<>();
            for (TrustYetki t : e.getValue()) lore.add(Yazi.k("&a✔ &7" + t.ad));
            lore.add(Yazi.k(""));
            lore.add(Yazi.k("&8▸ &7Sol tık: &fyetkileri düzenle"));
            lore.add(Yazi.k("&8▸ &7Sağ tık: &ctüm yetkileri al"));
            ItemStack it;
            if (u.equals(Claim.HERKES)) {
                it = esya(Material.NETHER_STAR, "&eHerkes", lore);
            } else {
                it = new ItemStack(Material.PLAYER_HEAD);
                SkullMeta sm = (SkullMeta) it.getItemMeta();
                sm.setOwningPlayer(Bukkit.getOfflinePlayer(u));
                sm.displayName(Yazi.k("&e" + ad(u)));
                sm.lore(lore);
                it.setItemMeta(sm);
            }
            env.setItem(i++, it);
        }
        if (sira.isEmpty()) {
            env.setItem(22, esya(Material.BARRIER, "&7Kimseye yetki verilmemiş", "&7Yetki vermek için: &f/trust <oyuncu>"));
        }
        env.setItem(49, esya(Material.ARROW, "&7« Claim Menüsü"));
        env.setItem(53, esya(Material.BARRIER, "&cKapat"));
    }

    @Override
    public void tikla(InventoryClickEvent e) {
        Player p = (Player) e.getWhoClicked();
        if (!claim.sahip.equals(p.getUniqueId()) && !p.hasPermission("korumasistemi.admin")) {
            p.closeInventory();
            return;
        }
        int s = e.getSlot();
        if (s == 53) {
            p.closeInventory();
        } else if (s == 49) {
            ClaimMenusu.ac(pl, p, claim);
        } else if (s >= 0 && s < sira.size()) {
            UUID u = sira.get(s);
            if (e.getClick().isRightClick()) {
                claim.guven.remove(u);
                pl.yonetici().kaydetPlanla();
                yenile();
            } else {
                TrustMenusu.ac(pl, p, claim, u, ad(u));
            }
        }
    }
}
