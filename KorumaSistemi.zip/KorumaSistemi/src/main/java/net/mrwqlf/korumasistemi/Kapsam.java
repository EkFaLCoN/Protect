package net.mrwqlf.korumasistemi;

/** Bir bayrağın hangi katmanlarda ayarlanabildiğini belirten bit değerleri. */
public final class Kapsam {
    public static final int D = 1;      // dünya
    public static final int B = 2;      // bölge
    public static final int C = 4;      // claim
    public static final int DB = D | B;
    public static final int HEPSI = D | B | C;

    private Kapsam() {}
}
