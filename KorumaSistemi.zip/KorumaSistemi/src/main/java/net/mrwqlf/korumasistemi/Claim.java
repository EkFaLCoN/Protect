package net.mrwqlf.korumasistemi;

import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public final class Claim extends BayrakSahibi {
    /** /trust herkes için kullanılan özel kimlik. */
    public static final UUID HERKES = new UUID(0L, 0L);

    public final UUID id;
    public final UUID sahip;
    public String sahipAdi;
    public final UUID dunya;
    public final String dunyaAdi;
    public final int minX, minZ, maxX, maxZ;
    public final long olusturma;
    public final Map<UUID, EnumSet<TrustYetki>> guven = new LinkedHashMap<>();

    public Claim(UUID id, UUID sahip, String sahipAdi, UUID dunya, String dunyaAdi,
                 int minX, int minZ, int maxX, int maxZ, long olusturma) {
        this.id = id;
        this.sahip = sahip;
        this.sahipAdi = sahipAdi;
        this.dunya = dunya;
        this.dunyaAdi = dunyaAdi;
        this.minX = minX;
        this.minZ = minZ;
        this.maxX = maxX;
        this.maxZ = maxZ;
        this.olusturma = olusturma;
    }

    public boolean icinde(int x, int z) {
        return x >= minX && x <= maxX && z >= minZ && z <= maxZ;
    }

    public boolean kesisir(int aMinX, int aMinZ, int aMaxX, int aMaxZ) {
        return !(aMaxX < minX || aMinX > maxX || aMaxZ < minZ || aMinZ > maxZ);
    }

    public boolean yetkili(UUID u, TrustYetki y) {
        if (u.equals(sahip)) return true;
        EnumSet<TrustYetki> s = guven.get(u);
        if (s != null && s.contains(y)) return true;
        EnumSet<TrustYetki> h = guven.get(HERKES);
        return h != null && h.contains(y);
    }

    /** Sahip, ya da herhangi bir yetkisi olan (veya herkese yetki verilmiş) oyuncu mu? */
    public boolean herhangiYetki(UUID u) {
        return u.equals(sahip) || guven.containsKey(u) || guven.containsKey(HERKES);
    }

    public int genislik() {
        return maxX - minX + 1;
    }

    public int uzunluk() {
        return maxZ - minZ + 1;
    }

    public long alan() {
        return (long) genislik() * uzunluk();
    }

    @Override
    public Katman katman() {
        return Katman.CLAIM;
    }

    @Override
    public String baslik() {
        return sahipAdi + " Claim'i";
    }
}
