package net.mrwqlf.korumasistemi;

import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Claim sınırlarını ve seçilen köşeleri parçacıkla gösterir. */
public final class Sinir {
    private Sinir() {}

    private static void nokta(Player p, double x, double y, double z) {
        p.spawnParticle(Particle.END_ROD, x + 0.5, y, z + 0.5, 1, 0, 0, 0, 0);
    }

    public static void goster(KorumaSistemi pl, Player p, Claim c) {
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (!p.isOnline() || ++n > 14 || !p.getWorld().getUID().equals(c.dunya)) {
                    cancel();
                    return;
                }
                double y = p.getLocation().getY() + 1.0;
                int px = p.getLocation().getBlockX();
                int pz = p.getLocation().getBlockZ();
                int r = 40;
                for (int x = Math.max(c.minX, px - r); x <= Math.min(c.maxX, px + r); x += 2) {
                    if (Math.abs(c.minZ - pz) <= r) {
                        nokta(p, x, y, c.minZ);
                        nokta(p, x, y + 2, c.minZ);
                    }
                    if (Math.abs(c.maxZ - pz) <= r) {
                        nokta(p, x, y, c.maxZ);
                        nokta(p, x, y + 2, c.maxZ);
                    }
                }
                for (int z = Math.max(c.minZ, pz - r); z <= Math.min(c.maxZ, pz + r); z += 2) {
                    if (Math.abs(c.minX - px) <= r) {
                        nokta(p, c.minX, y, z);
                        nokta(p, c.minX, y + 2, z);
                    }
                    if (Math.abs(c.maxX - px) <= r) {
                        nokta(p, c.maxX, y, z);
                        nokta(p, c.maxX, y + 2, z);
                    }
                }
            }
        }.runTaskTimer(pl, 0L, 10L);
    }

    /** Seçilen köşede kısa süre ışık sütunu gösterir. */
    public static void isaret(KorumaSistemi pl, Player p, int x, int y, int z) {
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (!p.isOnline() || ++n > 10) {
                    cancel();
                    return;
                }
                for (int i = 0; i < 8; i++) nokta(p, x, y + 1 + i * 0.5, z);
            }
        }.runTaskTimer(pl, 0L, 10L);
    }
}
