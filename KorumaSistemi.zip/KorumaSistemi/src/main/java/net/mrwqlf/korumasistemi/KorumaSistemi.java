package net.mrwqlf.korumasistemi;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.PluginCommand;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class KorumaSistemi extends JavaPlugin {
    private KorumaYoneticisi yonetici;
    private AlanGorevi alanGorevi;
    private BolgeSecimi bolgeSecimi;
    private NamespacedKey baltaAnahtari;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        baltaAnahtari = new NamespacedKey(this, "bolge_baltasi");
        yonetici = new KorumaYoneticisi(this);
        yonetici.yukle();
        bolgeSecimi = new BolgeSecimi();
        alanGorevi = new AlanGorevi(this);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new KorumaDinleyici(this), this);
        pm.registerEvents(new ClaimAraciDinleyici(this), this);
        pm.registerEvents(new MenuDinleyici(), this);

        Komutlar komutlar = new Komutlar(this);
        for (String ad : List.of("protect", "region", "claim", "trust", "untrust")) {
            PluginCommand pc = getCommand(ad);
            if (pc != null) {
                pc.setExecutor(komutlar);
                pc.setTabCompleter(komutlar);
            }
        }

        getServer().getScheduler().runTaskTimer(this, alanGorevi, 20L, 10L);
        getServer().getScheduler().runTaskTimer(this, new KarGorevi(this), 40L, 4L);
        getServer().getScheduler().runTaskTimer(this, new DunyaGorevi(this), 40L, 40L);

        getLogger().info("KorumaSistemi aktif! " + yonetici.claimler().size() + " claim yüklendi.");
    }

    @Override
    public void onDisable() {
        if (alanGorevi != null) alanGorevi.hepsiniTemizle();
        if (yonetici != null) yonetici.kaydet();
    }

    public KorumaYoneticisi yonetici() {
        return yonetici;
    }

    public AlanGorevi alanGorevi() {
        return alanGorevi;
    }

    public BolgeSecimi bolgeSecimi() {
        return bolgeSecimi;
    }

    public ItemStack baltaOlustur() {
        ItemStack it = new ItemStack(Material.WOODEN_AXE);
        ItemMeta m = it.getItemMeta();
        m.displayName(Yazi.k("&6Bölge Baltası"));
        m.lore(List.<Component>of(
                Yazi.k("&7Sol tık: &f1. nokta"),
                Yazi.k("&7Sağ tık: &f2. nokta"),
                Yazi.k("&7Sonra: &f/region create <ad> [full]")));
        m.getPersistentDataContainer().set(baltaAnahtari, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    public boolean baltaMi(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(baltaAnahtari, PersistentDataType.BYTE);
    }
}
