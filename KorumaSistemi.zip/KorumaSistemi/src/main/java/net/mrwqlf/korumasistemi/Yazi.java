package net.mrwqlf.korumasistemi;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public final class Yazi {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    public static final String ON = "&8[&bKoruma&8] &7";

    private Yazi() {}

    /** '&' renk kodlu metni, italik olmayan Component'e çevirir. */
    public static Component k(String s) {
        return LEGACY.deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    public static void mesaj(CommandSender g, String s) {
        g.sendMessage(k(ON + s));
    }

    public static void aksiyon(Player p, String s) {
        p.sendActionBar(k(s));
    }

    /** Uzun açıklamayı, renk önekiyle birlikte satırlara böler. */
    public static List<Component> sar(String renk, String metin, int genislik) {
        List<Component> sonuc = new ArrayList<>();
        StringBuilder satir = new StringBuilder();
        for (String kelime : metin.split(" ")) {
            if (satir.length() + kelime.length() + 1 > genislik && satir.length() > 0) {
                sonuc.add(k(renk + satir));
                satir.setLength(0);
            }
            if (satir.length() > 0) satir.append(' ');
            satir.append(kelime);
        }
        if (satir.length() > 0) sonuc.add(k(renk + satir));
        return sonuc;
    }
}
