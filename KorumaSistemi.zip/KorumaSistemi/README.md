# KorumaSistemi (Paper 26.x, Java 25)

WorldGuard tarzı dünya/bölge koruması + altın kürekle claim sistemi. %100 Türkçe, bağımlılık yok.

## Kurulum
1. Bu klasörü GitHub'a yükle; Actions `Derle` iş akışı `KorumaSistemi.jar` üretir.
2. Jar'ı exaroton paneli → Eklentiler üzerinden sunucuya yükle, sunucuyu yeniden başlat.

## Yönetici
- `/protect` — bulunduğun dünyanın koruma paneli (bayraklar). **TAM KORUMA** düğmesi tek tıkla dünyayı korur.
- Panelde: Hava Kilidi, Zaman Kilidi, **Kar Yağışı** (hafif/yoğun), **Kar Birikmesi**, PvP, patlama, yangın, mob, tarla...
- `/protect bypass` — korumaları aşmayı aç/kapa (yöneticiler varsayılan olarak aşar)
- `/protect info` — bulunduğun yerdeki etkin ayarlar
- `/protect clearsnow [yarıçap]` — biriken kar tabakalarını temizle
- `/region wand` → iki nokta seç → `/region create <ad> [full]` → `/region flag <ad>`
- `/region member add|remove <ad> <oyuncu>`, `/region priority`, `/region list|info|delete|tp`

Öncelik: **Bölge > Claim > Dünya**. Bölge oluşturulunca üye olmayanlar inşa edemez (WorldGuard gibi).

## Oyuncu
- `/claim shovel` — altın kürek. İki köşeye **sağ tık** = claim. Eğil+sağ tık: iptal. Eğil+sol tık: bilgi.
- `/claim` — claim menüsü (bilgi, bayraklar, güvenilenler, sil)
- `/trust <oyuncu|everyone>` — **yetki seçme ekranı** (kırma, koyma, kapı/düğme, sandık, kova, çerçeve, hayvan)
- `/untrust <oyuncu|everyone>`, `/claim list|info|border|delete`

## Ayarlar (config.yml)
Claim limitleri (herkes 1000 blok claim hakkıyla başlar), kar yarıçapı/katmanı/yoğunluğu.

## İzinler
`korumasistemi.admin` (op), `korumasistemi.claim` (herkes), `korumasistemi.sinirsiz` (op)

## Kapatılan açıklar (claim/bölge içi)
- Huni, huni-vagon ve düşürücü ile sandıktan/sandığa eşya taşıma (alan dışı <-> içi engellenir; aynı sahibin claim'leri arası serbest)
- Dışarıdaki dağıtıcıdan su/lav/TNT/ateş/yumurta boşaltma
- Piston, su ve lav ile sınırdan içeri müdahale; ağacın sınırdan içeri büyümesi
- Sandıklı tekne, depolu/hunili vagon (konteyner gibi korunur)
- Kova ile balık/aksolotl alma, kaplumbağa yumurtası ezme, ocak/saksı/süslü küp kullanma
- Patlamayla zırh standı/araç hasarı

- Yerdeki eşya: claim'de sadece sahip/yetkili oyuncular eşya alıp atabilir (kendi attığı eşya ve yakın zamanda orada ölünce düşen eşyalar hariç)
- Ok ile düğme, hedef bloğu, çan, basınç plakası tetikleme ve alevli okla TNT/blok tutuşturma
- Portal: yetkisiz oyuncu için korumalı alana blok koyacak portal oluşmaz (mevcut portallar etkilenmez)

## Bilinen sınırlar
- Dağıtıcıdan atılan ok gibi oyuncu olmayan kaynaklar yalnızca dağıtıcının önündeki blok kontrolüyle sınırlandırılır.
- Bölge içi ve dünya genelinde portal oluşumu engellenmez (yalnızca claim/bölge içine denk gelenler).
